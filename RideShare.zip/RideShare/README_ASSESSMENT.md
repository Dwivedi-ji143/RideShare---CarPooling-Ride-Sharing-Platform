# RideShare - Assessment Ready

## Technology
- Java 21
- Spring Boot 3.3.4
- Spring MVC + JDBC
- JSP + JSTL
- MySQL 8
- BCrypt password hashing

## Fastest Eclipse setup
1. Install/start **MySQL 8** and make sure the MySQL service is running.
2. Open MySQL Workbench or the MySQL command line.
3. Run `database/reset-demo.sql` for a clean demonstration database.
   - This script intentionally deletes the old `carpooling_db` database.
   - If you need to preserve existing data, run `database/schema.sql` only and add your own users.
4. If your MySQL password is not `Shashank@123`, edit `src/main/resources/application.properties` or set the `DB_PASSWORD` environment variable.
5. In Eclipse: **File -> Import -> Maven -> Existing Maven Projects**, select this folder, Finish.
6. Make sure the project uses **JDK 21**.
7. Right-click `src/main/java/com/carpooling/CarPoolingApplication.java` -> **Run As -> Java Application**.
8. Open `http://localhost:8080/`.

## Demo accounts
All seeded accounts use password: `password123`

| Role | Email | Password |
|---|---|---|
| Admin | admin@carpooling.com | password123 |
| Driver | rahul.driver@example.com | password123 |
| Driver | ananya.driver@example.com | password123 |
| Passenger | shashank@example.com | password123 |
| Passenger | priya@example.com | password123 |

## Main assessment flow
### Passenger
Home -> Register/Login -> Find Ride -> Ride Details -> Book -> Confirmation -> My Bookings -> Cancel/Rate -> Notifications -> Report Issue -> Profile

### Driver
Login -> Dashboard -> My Vehicles -> Offer Ride -> Ride Details -> My Rides -> Complete/Cancel -> Notifications -> Profile

### Admin
Login with admin account -> Admin Dashboard -> Users -> Suspend/Reactivate -> Reports -> Resolve

## Important fix included
The project no longer relies on a nullable JDBC `GeneratedKeyHolder` value for user/ride/booking/vehicle inserts. After each insert it retrieves the created primary key from MySQL, preventing the registration flow from failing after a successful insert.

## If the browser shows an error
Check the Eclipse Console. The application now renders a friendly error page instead of the default Spring Boot Whitelabel page, while the real stack trace is printed to the console for debugging.

## Database connection
The default configuration is `root` with password `Shashank@123` because that is the database configuration supplied with this project. For another password, set `DB_PASSWORD` before starting the app, or edit `application.properties`.

Windows example:
```bat
set DB_PASSWORD=YourMySQLPassword
```

## Presentation checklist
- Start MySQL first.
- Run `setup-database.bat` once for a clean demo database.
- Start the Spring Boot app.
- Demonstrate Passenger registration/login and ride search/booking.
- Demonstrate Driver vehicle + ride creation.
- Demonstrate Admin user/report management.
- Show the database tables in MySQL Workbench if asked.
