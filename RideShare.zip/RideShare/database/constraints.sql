-- RideShare database validation
-- The canonical schema.sql already creates the required UNIQUE and CHECK constraints.
-- This file is intentionally non-destructive and can be run on an existing database.

USE carpooling_db;

SELECT 'Duplicate emails' AS check_name, COUNT(*) AS problems
FROM (SELECT email FROM users GROUP BY email HAVING COUNT(*) > 1) x
UNION ALL
SELECT 'Duplicate phones', COUNT(*)
FROM (SELECT phone FROM users GROUP BY phone HAVING COUNT(*) > 1) x
UNION ALL
SELECT 'Duplicate vehicle numbers', COUNT(*)
FROM (SELECT vehicle_number FROM vehicles GROUP BY vehicle_number HAVING COUNT(*) > 1) x
UNION ALL
SELECT 'Invalid vehicle seats', COUNT(*)
FROM vehicles WHERE seats NOT BETWEEN 1 AND 8
UNION ALL
SELECT 'Invalid ride seats', COUNT(*)
FROM rides WHERE total_seats NOT BETWEEN 1 AND 8 OR available_seats NOT BETWEEN 0 AND total_seats
UNION ALL
SELECT 'Invalid ride costs', COUNT(*)
FROM rides WHERE distance_km < 0 OR fuel_cost < 0 OR toll_cost < 0
UNION ALL
SELECT 'Invalid booking values', COUNT(*)
FROM bookings WHERE seats_booked NOT BETWEEN 1 AND 8 OR amount < 0;

SHOW CREATE TABLE users;
SHOW CREATE TABLE vehicles;
SHOW CREATE TABLE rides;
