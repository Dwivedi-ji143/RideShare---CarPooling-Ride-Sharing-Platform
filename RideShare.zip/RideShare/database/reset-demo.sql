-- RideShare demo reset
-- WARNING: This removes existing carpooling_db data. Use only for a fresh assessment/demo setup.

DROP DATABASE IF EXISTS carpooling_db;

-- ==========================================================
-- Car Pooling & Ride Sharing Platform - Database Schema
-- ==========================================================

CREATE DATABASE IF NOT EXISTS carpooling_db;
USE carpooling_db;

-- ----------------------------------------------------------
-- users
-- ----------------------------------------------------------
CREATE TABLE users (
    user_id         BIGINT AUTO_INCREMENT PRIMARY KEY,
    name            VARCHAR(100)  NOT NULL,
    email           VARCHAR(150)  NOT NULL UNIQUE,
    CONSTRAINT uq_users_phone UNIQUE (phone),
    phone           VARCHAR(15)   NOT NULL,
    password        VARCHAR(255)  NOT NULL,   -- BCrypt hash
    role            ENUM('PASSENGER','DRIVER','ADMIN') NOT NULL DEFAULT 'PASSENGER',
    city            VARCHAR(100),
    profile_image   VARCHAR(255)  DEFAULT NULL,
    status          ENUM('ACTIVE','SUSPENDED') NOT NULL DEFAULT 'ACTIVE',
    created_at      TIMESTAMP     DEFAULT CURRENT_TIMESTAMP
);

-- ----------------------------------------------------------
-- vehicles
-- ----------------------------------------------------------
CREATE TABLE vehicles (
    vehicle_id      BIGINT AUTO_INCREMENT PRIMARY KEY,
    user_id         BIGINT NOT NULL,
    vehicle_number  VARCHAR(20)  NOT NULL,
    model           VARCHAR(100) NOT NULL,
    vehicle_type    ENUM('HATCHBACK','SEDAN','SUV','BIKE','OTHER') NOT NULL DEFAULT 'SEDAN',
    color           VARCHAR(30),
    seats           INT NOT NULL,
    CONSTRAINT chk_vehicle_seats CHECK (seats BETWEEN 1 AND 8),
    CONSTRAINT uq_vehicle_number UNIQUE (vehicle_number),
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_vehicle_user FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
);

-- ----------------------------------------------------------
-- rides
-- ----------------------------------------------------------
CREATE TABLE rides (
    ride_id          BIGINT AUTO_INCREMENT PRIMARY KEY,
    driver_id        BIGINT NOT NULL,
    vehicle_id       BIGINT NOT NULL,
    source           VARCHAR(150) NOT NULL,
    destination      VARCHAR(150) NOT NULL,
    departure_date   DATE NOT NULL,
    departure_time   TIME NOT NULL,
    available_seats  INT NOT NULL,
    total_seats      INT NOT NULL,
    distance_km      DECIMAL(6,2) DEFAULT 0,
    fuel_cost        DECIMAL(8,2) DEFAULT 0,
    toll_cost        DECIMAL(8,2) DEFAULT 0,
    notes            VARCHAR(500),
    status           ENUM('ACTIVE','COMPLETED','CANCELLED') NOT NULL DEFAULT 'ACTIVE',
    CONSTRAINT chk_ride_seats CHECK (total_seats BETWEEN 1 AND 8 AND available_seats BETWEEN 0 AND total_seats),
    CONSTRAINT chk_ride_costs CHECK (distance_km >= 0 AND fuel_cost >= 0 AND toll_cost >= 0),
    created_at       TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_ride_driver  FOREIGN KEY (driver_id)  REFERENCES users(user_id)    ON DELETE CASCADE,
    CONSTRAINT fk_ride_vehicle FOREIGN KEY (vehicle_id) REFERENCES vehicles(vehicle_id) ON DELETE CASCADE
);

-- ----------------------------------------------------------
-- bookings
-- ----------------------------------------------------------
CREATE TABLE bookings (
    booking_id      BIGINT AUTO_INCREMENT PRIMARY KEY,
    ride_id         BIGINT NOT NULL,
    passenger_id    BIGINT NOT NULL,
    seats_booked    INT NOT NULL,
    amount          DECIMAL(8,2) NOT NULL,
    status          ENUM('CONFIRMED','CANCELLED','COMPLETED') NOT NULL DEFAULT 'CONFIRMED',
    CONSTRAINT chk_booking_seats CHECK (seats_booked BETWEEN 1 AND 8),
    CONSTRAINT chk_booking_amount CHECK (amount >= 0),
    booked_at       TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_booking_ride      FOREIGN KEY (ride_id)      REFERENCES rides(ride_id) ON DELETE CASCADE,
    CONSTRAINT fk_booking_passenger FOREIGN KEY (passenger_id) REFERENCES users(user_id) ON DELETE CASCADE
);

-- ----------------------------------------------------------
-- ratings
-- ----------------------------------------------------------
CREATE TABLE ratings (
    rating_id       BIGINT AUTO_INCREMENT PRIMARY KEY,
    ride_id         BIGINT NOT NULL,
    driver_id       BIGINT NOT NULL,
    passenger_id    BIGINT NOT NULL,
    rating          TINYINT NOT NULL CHECK (rating BETWEEN 1 AND 5),
    review          VARCHAR(1000),
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_rating_ride      FOREIGN KEY (ride_id)      REFERENCES rides(ride_id) ON DELETE CASCADE,
    CONSTRAINT fk_rating_driver    FOREIGN KEY (driver_id)    REFERENCES users(user_id) ON DELETE CASCADE,
    CONSTRAINT fk_rating_passenger FOREIGN KEY (passenger_id) REFERENCES users(user_id) ON DELETE CASCADE,
    CONSTRAINT uq_rating_once UNIQUE (ride_id, passenger_id)
);

-- ----------------------------------------------------------
-- notifications
-- ----------------------------------------------------------
CREATE TABLE notifications (
    notification_id BIGINT AUTO_INCREMENT PRIMARY KEY,
    user_id         BIGINT NOT NULL,
    message         VARCHAR(500) NOT NULL,
    type            VARCHAR(50)  NOT NULL,
    is_read         BOOLEAN NOT NULL DEFAULT FALSE,
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_notification_user FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
);

-- ----------------------------------------------------------
-- reports
-- ----------------------------------------------------------
CREATE TABLE reports (
    report_id       BIGINT AUTO_INCREMENT PRIMARY KEY,
    reported_by     BIGINT NOT NULL,
    reported_user   BIGINT,
    ride_id         BIGINT,
    reason          VARCHAR(100) NOT NULL,
    description     VARCHAR(1000),
    status          ENUM('OPEN','REVIEWING','RESOLVED') NOT NULL DEFAULT 'OPEN',
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_report_reporter FOREIGN KEY (reported_by)   REFERENCES users(user_id) ON DELETE CASCADE,
    CONSTRAINT fk_report_target   FOREIGN KEY (reported_user) REFERENCES users(user_id) ON DELETE SET NULL,
    CONSTRAINT fk_report_ride     FOREIGN KEY (ride_id)       REFERENCES rides(ride_id) ON DELETE SET NULL
);

-- ----------------------------------------------------------
-- Indexes for search / dashboard performance
-- ----------------------------------------------------------
CREATE INDEX idx_rides_source        ON rides(source);
CREATE INDEX idx_rides_destination   ON rides(destination);
CREATE INDEX idx_rides_date          ON rides(departure_date);
CREATE INDEX idx_rides_status        ON rides(status);
CREATE INDEX idx_bookings_ride       ON bookings(ride_id);
CREATE INDEX idx_bookings_passenger  ON bookings(passenger_id);
CREATE INDEX idx_ratings_driver      ON ratings(driver_id);


USE carpooling_db;

-- Demo password for all seeded accounts: password123

INSERT INTO users (name, email, phone, password, role, city) VALUES
('Rahul Sharma',  'rahul.driver@example.com',  '9876543210', '$2a$10$OVnOaHDkcOXfbUZPFh5qt.yJqUt6pl9uJaqEMxxM.vS5fY/cZNmsq', 'DRIVER',    'Greater Noida'),
('Ananya Verma',  'ananya.driver@example.com', '9876543211', '$2a$10$OVnOaHDkcOXfbUZPFh5qt.yJqUt6pl9uJaqEMxxM.vS5fY/cZNmsq', 'DRIVER',    'Delhi'),
('Shashank Rao',  'shashank@example.com',      '9876543212', '$2a$10$OVnOaHDkcOXfbUZPFh5qt.yJqUt6pl9uJaqEMxxM.vS5fY/cZNmsq', 'PASSENGER', 'Knowledge Park'),
('Priya Singh',   'priya@example.com',         '9876543213', '$2a$10$OVnOaHDkcOXfbUZPFh5qt.yJqUt6pl9uJaqEMxxM.vS5fY/cZNmsq', 'PASSENGER', 'Noida'),
('Admin User',    'admin@carpooling.com',      '9999999999', '$2a$10$OVnOaHDkcOXfbUZPFh5qt.yJqUt6pl9uJaqEMxxM.vS5fY/cZNmsq', 'ADMIN',     'Delhi');

INSERT INTO vehicles (user_id, vehicle_number, model, vehicle_type, color, seats) VALUES
(1, 'UP16 XX 1234', 'Hyundai Creta', 'SUV',   'White', 4),
(2, 'DL05 YY 5678',  'Maruti Swift',  'HATCHBACK', 'Red', 3);

INSERT INTO rides (driver_id, vehicle_id, source, destination, departure_date, departure_time, available_seats, total_seats, distance_km, fuel_cost, toll_cost, notes, status) VALUES
(1, 1, 'Greater Noida', 'Delhi', '2026-09-15', '08:00:00', 3, 4, 45.0, 500.00, 200.00, 'AC car, non-smoking', 'ACTIVE'),
(2, 2, 'Delhi', 'Noida', '2026-09-15', '18:30:00', 2, 3, 25.0, 250.00, 100.00, 'Music allowed', 'ACTIVE');

INSERT INTO bookings (ride_id, passenger_id, seats_booked, amount, status) VALUES
(1, 3, 1, 175.00, 'CONFIRMED');

INSERT INTO ratings (ride_id, driver_id, passenger_id, rating, review) VALUES
(1, 1, 3, 5, 'Great driver, very punctual!');

INSERT INTO notifications (user_id, message, type, is_read) VALUES
(3, 'Your booking for Greater Noida -> Delhi is confirmed.', 'BOOKING_CONFIRMED', FALSE),
(1, 'New passenger booked a seat on your ride.', 'NEW_PASSENGER', FALSE);

