-- ==========================================================
-- Reference queries used by DAO classes
-- ==========================================================

-- Search available rides by route + date + seats
SELECT r.*, u.name AS driver_name, u.profile_image,
       v.model, v.vehicle_type,
       (SELECT ROUND(AVG(rt.rating),1) FROM ratings rt WHERE rt.driver_id = r.driver_id) AS avg_rating
FROM rides r
JOIN users u ON r.driver_id = u.user_id
JOIN vehicles v ON r.vehicle_id = v.vehicle_id
WHERE r.source LIKE CONCAT('%', ?, '%')
  AND r.destination LIKE CONCAT('%', ?, '%')
  AND r.departure_date = ?
  AND r.available_seats >= ?
  AND r.status = 'ACTIVE'
ORDER BY r.departure_time ASC;

-- Driver average rating + review count
SELECT ROUND(AVG(rating),1) AS avg_rating, COUNT(*) AS review_count
FROM ratings
WHERE driver_id = ?;

-- Passenger ride history
SELECT b.*, r.source, r.destination, r.departure_date, r.departure_time, u.name AS driver_name
FROM bookings b
JOIN rides r ON b.ride_id = r.ride_id
JOIN users u ON r.driver_id = u.user_id
WHERE b.passenger_id = ?
ORDER BY r.departure_date DESC;

-- Driver's offered rides with passenger counts
SELECT r.*, (SELECT COUNT(*) FROM bookings b WHERE b.ride_id = r.ride_id AND b.status = 'CONFIRMED') AS passenger_count
FROM rides r
WHERE r.driver_id = ?
ORDER BY r.departure_date DESC;

-- Admin dashboard statistics
SELECT
  (SELECT COUNT(*) FROM users WHERE role = 'PASSENGER') AS total_passengers,
  (SELECT COUNT(*) FROM users WHERE role = 'DRIVER')    AS total_drivers,
  (SELECT COUNT(*) FROM rides)                          AS total_rides,
  (SELECT COUNT(*) FROM rides WHERE status = 'ACTIVE')    AS active_rides,
  (SELECT COUNT(*) FROM rides WHERE status = 'COMPLETED') AS completed_rides,
  (SELECT COUNT(*) FROM rides WHERE status = 'CANCELLED') AS cancelled_rides,
  (SELECT COUNT(*) FROM reports WHERE status = 'OPEN')     AS open_reports;

-- Popular routes
SELECT source, destination, COUNT(*) AS ride_count
FROM rides
GROUP BY source, destination
ORDER BY ride_count DESC
LIMIT 5;

-- Atomic seat booking (used inside a transaction in BookingService)
UPDATE rides
SET available_seats = available_seats - ?
WHERE ride_id = ? AND available_seats >= ?;
