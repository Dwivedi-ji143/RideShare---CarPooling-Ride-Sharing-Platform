USE carpooling_db;

-- Demo password for all seeded accounts: password123

INSERT INTO users (name, email, phone, password, role, city) VALUES
('Rahul Sharma',  'rahul.driver@example.com',  '9876543210', '$2a$10$OVnOaHDkcOXfbUZPFh5qt.yJqUt6pl9uJaqEMxxM.vS5fY/cZNmsq', 'DRIVER',    'Greater Noida'),
('Ananya Verma',  'ananya.driver@example.com', '9876543211', '$2a$10$OVnOaHDkcOXfbUZPFh5qt.yJqUt6pl9uJaqEMxxM.vS5fY/cZNmsq', 'DRIVER',    'Delhi'),
('Shashank Rao',  'shashank@example.com',      '9876543212', '$2a$10$OVnOaHDkcOXfbUZPFh5qt.yJqUt6pl9uJaqEMxxM.vS5fY/cZNmsq', 'PASSENGER', 'Knowledge Park'),
('Priya Singh',   'priya@example.com',         '9876543213', '$2a$10$OVnOaHDkcOXfbUZPFh5qt.yJqUt6pl9uJaqEMxxM.vS5fY/cZNmsq', 'PASSENGER', 'Noida'),
('Admin User',    'admin@carpooling.com',      '9999999999', '$2a$10$OVnOaHDkcOXfbUZPFh5qt.yJqUt6pl9uJaqEMxxM.vS5fY/cZNmsq', 'ADMIN',     'Delhi');

INSERT INTO vehicles (user_id, vehicle_number, model, vehicle_type, color, seats) VALUES
(1, 'UP16 XX 1234', 'Hyundai Creta', 'SUV',   'White', 4),
(2, 'DL05 YY 5678',  'Maruti Swift',  'HATCHBACK', 'Red', 3);

INSERT INTO rides (driver_id, vehicle_id, source, destination, departure_date, departure_time, available_seats, total_seats, distance_km, fuel_cost, toll_cost, notes, status) VALUES
(1, 1, 'Greater Noida', 'Delhi', '2026-09-15', '08:00:00', 3, 4, 45.0, 500.00, 200.00, 'AC car, non-smoking', 'ACTIVE'),
(2, 2, 'Delhi', 'Noida', '2026-09-15', '18:30:00', 2, 3, 25.0, 250.00, 100.00, 'Music allowed', 'ACTIVE');

INSERT INTO bookings (ride_id, passenger_id, seats_booked, amount, status) VALUES
(1, 3, 1, 175.00, 'CONFIRMED');

INSERT INTO ratings (ride_id, driver_id, passenger_id, rating, review) VALUES
(1, 1, 3, 5, 'Great driver, very punctual!');

INSERT INTO notifications (user_id, message, type, is_read) VALUES
(3, 'Your booking for Greater Noida -> Delhi is confirmed.', 'BOOKING_CONFIRMED', FALSE),
(1, 'New passenger booked a seat on your ride.', 'NEW_PASSENGER', FALSE);
