package com.carpooling.model;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;

public class Ride {

    private Long id;
    private Long driverId;
    private Long vehicleId;
    private String source;
    private String destination;
    private LocalDate departureDate;
    private LocalTime departureTime;
    private int availableSeats;
    private int totalSeats;
    private BigDecimal distanceKm;
    private BigDecimal fuelCost;
    private BigDecimal tollCost;
    private String notes;
    private String status; // ACTIVE, COMPLETED, CANCELLED
    private LocalDateTime createdAt;

    // Joined / computed fields for display (populated by DAO joins, not DB columns)
    private String driverName;
    private String driverProfileImage;
    private Double driverRating;
    private String vehicleModel;
    private String vehicleType;
    private Integer passengerCount;
    private Integer routeCompatibility; // 0-100, used by route matching

    public Ride() {}

    /** Total trip cost = fuel + toll. */
    public BigDecimal getTotalCost() {
        BigDecimal fuel = fuelCost == null ? BigDecimal.ZERO : fuelCost;
        BigDecimal toll = tollCost == null ? BigDecimal.ZERO : tollCost;
        return fuel.add(toll);
    }

    /** Cost per passenger, split across driver + all seats (total_seats). */
    public BigDecimal getCostPerPerson() {
        if (totalSeats <= 0) return BigDecimal.ZERO;
        return getTotalCost().divide(BigDecimal.valueOf(totalSeats), 2, java.math.RoundingMode.HALF_UP);
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Long getDriverId() { return driverId; }
    public void setDriverId(Long driverId) { this.driverId = driverId; }

    public Long getVehicleId() { return vehicleId; }
    public void setVehicleId(Long vehicleId) { this.vehicleId = vehicleId; }

    public String getSource() { return source; }
    public void setSource(String source) { this.source = source; }

    public String getDestination() { return destination; }
    public void setDestination(String destination) { this.destination = destination; }

    public LocalDate getDepartureDate() { return departureDate; }
    public void setDepartureDate(LocalDate departureDate) { this.departureDate = departureDate; }

    public LocalTime getDepartureTime() { return departureTime; }
    public void setDepartureTime(LocalTime departureTime) { this.departureTime = departureTime; }

    public int getAvailableSeats() { return availableSeats; }
    public void setAvailableSeats(int availableSeats) { this.availableSeats = availableSeats; }

    public int getTotalSeats() { return totalSeats; }
    public void setTotalSeats(int totalSeats) { this.totalSeats = totalSeats; }

    public BigDecimal getDistanceKm() { return distanceKm; }
    public void setDistanceKm(BigDecimal distanceKm) { this.distanceKm = distanceKm; }

    public BigDecimal getFuelCost() { return fuelCost; }
    public void setFuelCost(BigDecimal fuelCost) { this.fuelCost = fuelCost; }

    public BigDecimal getTollCost() { return tollCost; }
    public void setTollCost(BigDecimal tollCost) { this.tollCost = tollCost; }

    public String getNotes() { return notes; }
    public void setNotes(String notes) { this.notes = notes; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }

    public String getDriverName() { return driverName; }
    public void setDriverName(String driverName) { this.driverName = driverName; }

    public String getDriverProfileImage() { return driverProfileImage; }
    public void setDriverProfileImage(String driverProfileImage) { this.driverProfileImage = driverProfileImage; }

    public Double getDriverRating() { return driverRating; }
    public void setDriverRating(Double driverRating) { this.driverRating = driverRating; }

    public String getVehicleModel() { return vehicleModel; }
    public void setVehicleModel(String vehicleModel) { this.vehicleModel = vehicleModel; }

    public String getVehicleType() { return vehicleType; }
    public void setVehicleType(String vehicleType) { this.vehicleType = vehicleType; }

    public Integer getPassengerCount() { return passengerCount; }
    public void setPassengerCount(Integer passengerCount) { this.passengerCount = passengerCount; }

    public Integer getRouteCompatibility() { return routeCompatibility; }
    public void setRouteCompatibility(Integer routeCompatibility) { this.routeCompatibility = routeCompatibility; }
}
