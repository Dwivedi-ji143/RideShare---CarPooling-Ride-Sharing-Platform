package com.carpooling.model;

public class Vehicle {

    private Long id;
    private Long userId;
    private String vehicleNumber;
    private String model;
    private String vehicleType; // HATCHBACK, SEDAN, SUV, BIKE, OTHER
    private String color;
    private int seats;

    public Vehicle() {}

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Long getUserId() { return userId; }
    public void setUserId(Long userId) { this.userId = userId; }

    public String getVehicleNumber() { return vehicleNumber; }
    public void setVehicleNumber(String vehicleNumber) { this.vehicleNumber = vehicleNumber; }

    public String getModel() { return model; }
    public void setModel(String model) { this.model = model; }

    public String getVehicleType() { return vehicleType; }
    public void setVehicleType(String vehicleType) { this.vehicleType = vehicleType; }

    public String getColor() { return color; }
    public void setColor(String color) { this.color = color; }

    public int getSeats() { return seats; }
    public void setSeats(int seats) { this.seats = seats; }
}
