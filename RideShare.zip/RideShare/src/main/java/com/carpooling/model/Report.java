package com.carpooling.model;

import java.time.LocalDateTime;

public class Report {

    private Long id;
    private Long reportedBy;
    private Long reportedUser;
    private Long rideId;
    private String reason;
    private String description;
    private String status; // OPEN, REVIEWING, RESOLVED
    private LocalDateTime createdAt;

    // Joined display fields
    private String reporterName;
    private String reportedUserName;

    public Report() {}

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Long getReportedBy() { return reportedBy; }
    public void setReportedBy(Long reportedBy) { this.reportedBy = reportedBy; }

    public Long getReportedUser() { return reportedUser; }
    public void setReportedUser(Long reportedUser) { this.reportedUser = reportedUser; }

    public Long getRideId() { return rideId; }
    public void setRideId(Long rideId) { this.rideId = rideId; }

    public String getReason() { return reason; }
    public void setReason(String reason) { this.reason = reason; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }

    public String getReporterName() { return reporterName; }
    public void setReporterName(String reporterName) { this.reporterName = reporterName; }

    public String getReportedUserName() { return reportedUserName; }
    public void setReportedUserName(String reportedUserName) { this.reportedUserName = reportedUserName; }
}
