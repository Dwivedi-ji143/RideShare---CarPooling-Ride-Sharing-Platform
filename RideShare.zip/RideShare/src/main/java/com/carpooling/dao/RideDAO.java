package com.carpooling.dao;

import com.carpooling.model.Ride;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@Repository
public class RideDAO {

    private final JdbcTemplate jdbcTemplate;

    public RideDAO(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    /** Base SELECT that joins driver + vehicle + average rating for display-ready ride cards. */
    private static final String SELECT_BASE =
        "SELECT r.*, u.name AS driver_name, u.profile_image AS driver_profile_image, " +
        "       v.model AS vehicle_model, v.vehicle_type AS vehicle_type, " +
        "       (SELECT ROUND(AVG(rt.rating),1) FROM ratings rt WHERE rt.driver_id = r.driver_id) AS driver_rating, " +
        "       (SELECT COUNT(*) FROM bookings b WHERE b.ride_id = r.ride_id AND b.status = 'CONFIRMED') AS passenger_count " +
        "FROM rides r " +
        "JOIN users u ON r.driver_id = u.user_id " +
        "JOIN vehicles v ON r.vehicle_id = v.vehicle_id ";

    private static final RowMapper<Ride> RIDE_MAPPER = (rs, rowNum) -> {
        Ride r = new Ride();
        r.setId(rs.getLong("ride_id"));
        r.setDriverId(rs.getLong("driver_id"));
        r.setVehicleId(rs.getLong("vehicle_id"));
        r.setSource(rs.getString("source"));
        r.setDestination(rs.getString("destination"));
        r.setDepartureDate(rs.getDate("departure_date").toLocalDate());
        r.setDepartureTime(rs.getTime("departure_time").toLocalTime());
        r.setAvailableSeats(rs.getInt("available_seats"));
        r.setTotalSeats(rs.getInt("total_seats"));
        r.setDistanceKm(rs.getBigDecimal("distance_km"));
        r.setFuelCost(rs.getBigDecimal("fuel_cost"));
        r.setTollCost(rs.getBigDecimal("toll_cost"));
        r.setNotes(rs.getString("notes"));
        r.setStatus(rs.getString("status"));
        if (rs.getTimestamp("created_at") != null) {
            r.setCreatedAt(rs.getTimestamp("created_at").toLocalDateTime());
        }
        r.setDriverName(rs.getString("driver_name"));
        r.setDriverProfileImage(rs.getString("driver_profile_image"));
        r.setVehicleModel(rs.getString("vehicle_model"));
        r.setVehicleType(rs.getString("vehicle_type"));
        double rating = rs.getDouble("driver_rating");
        r.setDriverRating(rs.wasNull() ? null : rating);
        r.setPassengerCount(rs.getInt("passenger_count"));
        return r;
    };

    public Long insert(Ride ride) {
        String sql = "INSERT INTO rides (driver_id, vehicle_id, source, destination, departure_date, departure_time, " +
                "available_seats, total_seats, distance_km, fuel_cost, toll_cost, notes, status) " +
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'ACTIVE')";
        jdbcTemplate.update(sql, ride.getDriverId(), ride.getVehicleId(), ride.getSource(),
                ride.getDestination(), java.sql.Date.valueOf(ride.getDepartureDate()),
                java.sql.Time.valueOf(ride.getDepartureTime()), ride.getAvailableSeats(),
                ride.getTotalSeats(), ride.getDistanceKm(), ride.getFuelCost(), ride.getTollCost(),
                ride.getNotes());
        Long id = jdbcTemplate.queryForObject(
                "SELECT ride_id FROM rides WHERE driver_id = ? AND vehicle_id = ? AND source = ? " +
                "AND destination = ? AND departure_date = ? AND departure_time = ? " +
                "ORDER BY ride_id DESC LIMIT 1", Long.class, ride.getDriverId(), ride.getVehicleId(),
                ride.getSource(), ride.getDestination(), java.sql.Date.valueOf(ride.getDepartureDate()),
                java.sql.Time.valueOf(ride.getDepartureTime()));
        if (id == null) throw new IllegalStateException("Ride was created but its ID could not be retrieved.");
        return id;
    }

    public Optional<Ride> findById(Long id) {
        return jdbcTemplate.query(SELECT_BASE + " WHERE r.ride_id = ?", RIDE_MAPPER, id).stream().findFirst();
    }

    /** Core search used by Section 5.6 — source/destination/date/seats + optional filters. */
    public List<Ride> search(String source, String destination, LocalDate date, int seats,
                              BigDecimal maxCost, Double minRating, String vehicleType) {
        StringBuilder sql = new StringBuilder(SELECT_BASE);
        sql.append(" WHERE r.status = 'ACTIVE' AND r.available_seats >= ? ");
        java.util.List<Object> params = new java.util.ArrayList<>();
        params.add(seats);

        if (source != null && !source.isBlank()) {
            sql.append(" AND r.source LIKE ? ");
            params.add("%" + source + "%");
        }
        if (destination != null && !destination.isBlank()) {
            sql.append(" AND r.destination LIKE ? ");
            params.add("%" + destination + "%");
        }
        if (date != null) {
            sql.append(" AND r.departure_date = ? ");
            params.add(java.sql.Date.valueOf(date));
        }
        if (vehicleType != null && !vehicleType.isBlank()) {
            sql.append(" AND v.vehicle_type = ? ");
            params.add(vehicleType);
        }
        sql.append(" ORDER BY r.departure_date ASC, r.departure_time ASC");

        List<Ride> rides = jdbcTemplate.query(sql.toString(), RIDE_MAPPER, params.toArray());

        // Post-filter on computed fields (cost/person, avg rating) since they aren't plain columns
        return rides.stream()
                .filter(r -> maxCost == null || r.getCostPerPerson().compareTo(maxCost) <= 0)
                .filter(r -> minRating == null || (r.getDriverRating() != null && r.getDriverRating() >= minRating))
                .toList();
    }

    public List<Ride> findByDriverId(Long driverId) {
        return jdbcTemplate.query(SELECT_BASE + " WHERE r.driver_id = ? ORDER BY r.departure_date DESC", RIDE_MAPPER, driverId);
    }

    /** Atomic, overbooking-safe seat deduction. Returns true if the update actually applied. */
    public boolean decrementSeats(Long rideId, int seats) {
        String sql = "UPDATE rides SET available_seats = available_seats - ? WHERE ride_id = ? AND available_seats >= ?";
        int rows = jdbcTemplate.update(sql, seats, rideId, seats);
        return rows > 0;
    }

    public void incrementSeats(Long rideId, int seats) {
        jdbcTemplate.update("UPDATE rides SET available_seats = available_seats + ? WHERE ride_id = ?", seats, rideId);
    }

    public void updateStatus(Long rideId, String status) {
        jdbcTemplate.update("UPDATE rides SET status = ? WHERE ride_id = ?", status, rideId);
    }

    public void update(Ride ride) {
        String sql = "UPDATE rides SET source=?, destination=?, departure_date=?, departure_time=?, " +
                "fuel_cost=?, toll_cost=?, notes=? WHERE ride_id = ? AND driver_id = ?";
        jdbcTemplate.update(sql, ride.getSource(), ride.getDestination(),
                java.sql.Date.valueOf(ride.getDepartureDate()), java.sql.Time.valueOf(ride.getDepartureTime()),
                ride.getFuelCost(), ride.getTollCost(), ride.getNotes(), ride.getId(), ride.getDriverId());
    }

    public long countAll() {
        Long c = jdbcTemplate.queryForObject("SELECT COUNT(*) FROM rides", Long.class);
        return c == null ? 0 : c;
    }

    public long countByStatus(String status) {
        Long c = jdbcTemplate.queryForObject("SELECT COUNT(*) FROM rides WHERE status = ?", Long.class, status);
        return c == null ? 0 : c;
    }

    public List<Map<String, Object>> popularRoutes(int limit) {
        String sql = "SELECT source, destination, COUNT(*) AS ride_count FROM rides " +
                "GROUP BY source, destination ORDER BY ride_count DESC LIMIT ?";
        return jdbcTemplate.queryForList(sql, limit);
    }
}
