package com.carpooling.dao;

import com.carpooling.model.Rating;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

@Repository
public class RatingDAO {

    private final JdbcTemplate jdbcTemplate;

    public RatingDAO(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    private static final RowMapper<Rating> RATING_MAPPER = (rs, rowNum) -> {
        Rating r = new Rating();
        r.setId(rs.getLong("rating_id"));
        r.setRideId(rs.getLong("ride_id"));
        r.setDriverId(rs.getLong("driver_id"));
        r.setPassengerId(rs.getLong("passenger_id"));
        r.setRating(rs.getInt("rating"));
        r.setReview(rs.getString("review"));
        if (rs.getTimestamp("created_at") != null) {
            r.setCreatedAt(rs.getTimestamp("created_at").toLocalDateTime());
        }
        r.setPassengerName(rs.getString("passenger_name"));
        return r;
    };

    public void insert(Rating rating) {
        String sql = "INSERT INTO ratings (ride_id, driver_id, passenger_id, rating, review) VALUES (?, ?, ?, ?, ?)";
        jdbcTemplate.update(sql, rating.getRideId(), rating.getDriverId(), rating.getPassengerId(),
                rating.getRating(), rating.getReview());
    }

    public boolean alreadyRated(Long rideId, Long passengerId) {
        Integer count = jdbcTemplate.queryForObject(
                "SELECT COUNT(*) FROM ratings WHERE ride_id = ? AND passenger_id = ?", Integer.class, rideId, passengerId);
        return count != null && count > 0;
    }

    public List<Rating> findByDriverId(Long driverId) {
        String sql = "SELECT rt.*, u.name AS passenger_name FROM ratings rt " +
                "JOIN users u ON rt.passenger_id = u.user_id " +
                "WHERE rt.driver_id = ? ORDER BY rt.created_at DESC";
        return jdbcTemplate.query(sql, RATING_MAPPER, driverId);
    }

    public Map<String, Object> summaryForDriver(Long driverId) {
        String sql = "SELECT ROUND(AVG(rating),1) AS avg_rating, COUNT(*) AS review_count FROM ratings WHERE driver_id = ?";
        return jdbcTemplate.queryForMap(sql, driverId);
    }
}
