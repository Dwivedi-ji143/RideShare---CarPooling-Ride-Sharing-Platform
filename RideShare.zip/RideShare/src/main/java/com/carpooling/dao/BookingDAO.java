package com.carpooling.dao;

import com.carpooling.model.Booking;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public class BookingDAO {

    private final JdbcTemplate jdbcTemplate;

    public BookingDAO(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    private static final String SELECT_BASE =
        "SELECT b.*, r.source, r.destination, r.departure_date, r.departure_time, " +
        "       du.name AS driver_name, pu.name AS passenger_name " +
        "FROM bookings b " +
        "JOIN rides r ON b.ride_id = r.ride_id " +
        "JOIN users du ON r.driver_id = du.user_id " +
        "JOIN users pu ON b.passenger_id = pu.user_id ";

    private static final RowMapper<Booking> BOOKING_MAPPER = (rs, rowNum) -> {
        Booking b = new Booking();
        b.setId(rs.getLong("booking_id"));
        b.setRideId(rs.getLong("ride_id"));
        b.setPassengerId(rs.getLong("passenger_id"));
        b.setSeatsBooked(rs.getInt("seats_booked"));
        b.setAmount(rs.getBigDecimal("amount"));
        b.setStatus(rs.getString("status"));
        if (rs.getTimestamp("booked_at") != null) {
            b.setBookedAt(rs.getTimestamp("booked_at").toLocalDateTime());
        }
        b.setSource(rs.getString("source"));
        b.setDestination(rs.getString("destination"));
        b.setDepartureDate(rs.getDate("departure_date").toString());
        b.setDepartureTime(rs.getTime("departure_time").toString());
        b.setDriverName(rs.getString("driver_name"));
        b.setPassengerName(rs.getString("passenger_name"));
        return b;
    };

    public Long insert(Booking booking) {
        String sql = "INSERT INTO bookings (ride_id, passenger_id, seats_booked, amount, status) VALUES (?, ?, ?, ?, 'CONFIRMED')";
        jdbcTemplate.update(sql, booking.getRideId(), booking.getPassengerId(),
                booking.getSeatsBooked(), booking.getAmount());
        Long id = jdbcTemplate.queryForObject(
                "SELECT booking_id FROM bookings WHERE ride_id = ? AND passenger_id = ? " +
                "AND seats_booked = ? AND amount = ? ORDER BY booking_id DESC LIMIT 1",
                Long.class, booking.getRideId(), booking.getPassengerId(),
                booking.getSeatsBooked(), booking.getAmount());
        if (id == null) throw new IllegalStateException("Booking was created but its ID could not be retrieved.");
        return id;
    }


    public boolean existsConfirmed(Long rideId, Long passengerId) {
        Integer count = jdbcTemplate.queryForObject(
                "SELECT COUNT(*) FROM bookings WHERE ride_id = ? AND passenger_id = ? AND status = 'CONFIRMED'",
                Integer.class, rideId, passengerId);
        return count != null && count > 0;
    }

    public Optional<Booking> findById(Long id) {
        return jdbcTemplate.query(SELECT_BASE + " WHERE b.booking_id = ?", BOOKING_MAPPER, id).stream().findFirst();
    }

    public List<Booking> findByPassengerId(Long passengerId) {
        return jdbcTemplate.query(SELECT_BASE + " WHERE b.passenger_id = ? ORDER BY b.booked_at DESC", BOOKING_MAPPER, passengerId);
    }

    public List<Booking> findByRideId(Long rideId) {
        return jdbcTemplate.query(SELECT_BASE + " WHERE b.ride_id = ? ORDER BY b.booked_at ASC", BOOKING_MAPPER, rideId);
    }

    public void updateStatus(Long bookingId, String status) {
        jdbcTemplate.update("UPDATE bookings SET status = ? WHERE booking_id = ?", status, bookingId);
    }

    public long countAll() {
        Long c = jdbcTemplate.queryForObject("SELECT COUNT(*) FROM bookings", Long.class);
        return c == null ? 0 : c;
    }
}
