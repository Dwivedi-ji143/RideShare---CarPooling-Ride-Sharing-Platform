package com.carpooling.dao;

import com.carpooling.model.Report;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class ReportDAO {

    private final JdbcTemplate jdbcTemplate;

    public ReportDAO(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    private static final RowMapper<Report> MAPPER = (rs, rowNum) -> {
        Report r = new Report();
        r.setId(rs.getLong("report_id"));
        r.setReportedBy(rs.getLong("reported_by"));
        long targetUser = rs.getLong("reported_user");
        r.setReportedUser(rs.wasNull() ? null : targetUser);
        long rideId = rs.getLong("ride_id");
        r.setRideId(rs.wasNull() ? null : rideId);
        r.setReason(rs.getString("reason"));
        r.setDescription(rs.getString("description"));
        r.setStatus(rs.getString("status"));
        if (rs.getTimestamp("created_at") != null) {
            r.setCreatedAt(rs.getTimestamp("created_at").toLocalDateTime());
        }
        r.setReporterName(rs.getString("reporter_name"));
        r.setReportedUserName(rs.getString("reported_user_name"));
        return r;
    };

    public void insert(Report report) {
        String sql = "INSERT INTO reports (reported_by, reported_user, ride_id, reason, description) VALUES (?, ?, ?, ?, ?)";
        jdbcTemplate.update(sql, report.getReportedBy(), report.getReportedUser(), report.getRideId(),
                report.getReason(), report.getDescription());
    }

    public List<Report> findAll() {
        String sql = "SELECT r.*, u.name AS reporter_name, ru.name AS reported_user_name " +
                "FROM reports r " +
                "JOIN users u ON r.reported_by = u.user_id " +
                "LEFT JOIN users ru ON r.reported_user = ru.user_id " +
                "ORDER BY r.created_at DESC";
        return jdbcTemplate.query(sql, MAPPER);
    }

    public void updateStatus(Long reportId, String status) {
        jdbcTemplate.update("UPDATE reports SET status = ? WHERE report_id = ?", status, reportId);
    }

    public long countOpen() {
        Long c = jdbcTemplate.queryForObject("SELECT COUNT(*) FROM reports WHERE status = 'OPEN'", Long.class);
        return c == null ? 0 : c;
    }
}
