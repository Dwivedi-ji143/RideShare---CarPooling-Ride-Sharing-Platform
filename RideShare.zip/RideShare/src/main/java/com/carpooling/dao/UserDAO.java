package com.carpooling.dao;

import com.carpooling.model.User;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public class UserDAO {

    private final JdbcTemplate jdbcTemplate;

    public UserDAO(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    private static final RowMapper<User> USER_MAPPER = (rs, rowNum) -> {
        User u = new User();
        u.setId(rs.getLong("user_id"));
        u.setName(rs.getString("name"));
        u.setEmail(rs.getString("email"));
        u.setPhone(rs.getString("phone"));
        u.setPassword(rs.getString("password"));
        u.setRole(rs.getString("role"));
        u.setCity(rs.getString("city"));
        u.setProfileImage(rs.getString("profile_image"));
        u.setStatus(rs.getString("status"));
        if (rs.getTimestamp("created_at") != null) {
            u.setCreatedAt(rs.getTimestamp("created_at").toLocalDateTime());
        }
        return u;
    };

    public Long insert(User user) {
        String sql = "INSERT INTO users (name, email, phone, password, role, city) VALUES (?, ?, ?, ?, ?, ?)";
        jdbcTemplate.update(sql, user.getName(), user.getEmail(), user.getPhone(),
                user.getPassword(), user.getRole(), user.getCity());

        Long id = jdbcTemplate.queryForObject(
                "SELECT user_id FROM users WHERE email = ?", Long.class, user.getEmail());

        if (id == null) {
            throw new IllegalStateException("Account was created but its ID could not be retrieved.");
        }
        return id;
    }

    public Optional<User> findByEmail(String email) {
        String sql = "SELECT * FROM users WHERE email = ?";
        List<User> results = jdbcTemplate.query(sql, USER_MAPPER, email);
        return results.stream().findFirst();
    }

    public Optional<User> findById(Long id) {
        String sql = "SELECT * FROM users WHERE user_id = ?";
        List<User> results = jdbcTemplate.query(sql, USER_MAPPER, id);
        return results.stream().findFirst();
    }

    public boolean existsByEmail(String email) {
        String sql = "SELECT COUNT(*) FROM users WHERE email = ?";
        Integer count = jdbcTemplate.queryForObject(sql, Integer.class, email);
        return count != null && count > 0;
    }

    public boolean existsByPhone(String phone) {
        String sql = "SELECT COUNT(*) FROM users WHERE phone = ?";
        Integer count = jdbcTemplate.queryForObject(sql, Integer.class, phone);
        return count != null && count > 0;
    }

    public void updateProfile(User user) {
        String sql = "UPDATE users SET name = ?, phone = ?, city = ? WHERE user_id = ?";
        jdbcTemplate.update(sql, user.getName(), user.getPhone(), user.getCity(), user.getId());
    }

    public void updateProfileImage(Long userId, String imagePath) {
        String sql = "UPDATE users SET profile_image = ? WHERE user_id = ?";
        jdbcTemplate.update(sql, imagePath, userId);
    }

    public void updatePassword(Long userId, String newHashedPassword) {
        String sql = "UPDATE users SET password = ? WHERE user_id = ?";
        jdbcTemplate.update(sql, newHashedPassword, userId);
    }

    public void updateStatus(Long userId, String status) {
        String sql = "UPDATE users SET status = ? WHERE user_id = ?";
        jdbcTemplate.update(sql, status, userId);
    }

    public List<User> findAll() {
        return jdbcTemplate.query("SELECT * FROM users ORDER BY created_at DESC", USER_MAPPER);
    }

    public List<User> findByRole(String role) {
        return jdbcTemplate.query("SELECT * FROM users WHERE role = ? ORDER BY created_at DESC", USER_MAPPER, role);
    }

    public long countByRole(String role) {
        Long count = jdbcTemplate.queryForObject("SELECT COUNT(*) FROM users WHERE role = ?", Long.class, role);
        return count == null ? 0 : count;
    }
}
