package com.carpooling.dao;

import com.carpooling.model.Notification;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class NotificationDAO {

    private final JdbcTemplate jdbcTemplate;

    public NotificationDAO(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    private static final RowMapper<Notification> MAPPER = (rs, rowNum) -> {
        Notification n = new Notification();
        n.setId(rs.getLong("notification_id"));
        n.setUserId(rs.getLong("user_id"));
        n.setMessage(rs.getString("message"));
        n.setType(rs.getString("type"));
        n.setRead(rs.getBoolean("is_read"));
        if (rs.getTimestamp("created_at") != null) {
            n.setCreatedAt(rs.getTimestamp("created_at").toLocalDateTime());
        }
        return n;
    };

    public void insert(Long userId, String message, String type) {
        jdbcTemplate.update("INSERT INTO notifications (user_id, message, type) VALUES (?, ?, ?)",
                userId, message, type);
    }

    public List<Notification> findByUserId(Long userId) {
        return jdbcTemplate.query(
                "SELECT * FROM notifications WHERE user_id = ? ORDER BY created_at DESC LIMIT 50",
                MAPPER, userId);
    }

    public long countUnread(Long userId) {
        Long c = jdbcTemplate.queryForObject(
                "SELECT COUNT(*) FROM notifications WHERE user_id = ? AND is_read = FALSE", Long.class, userId);
        return c == null ? 0 : c;
    }

    public void markRead(Long notificationId) {
        jdbcTemplate.update("UPDATE notifications SET is_read = TRUE WHERE notification_id = ?", notificationId);
    }

    public void markAllRead(Long userId) {
        jdbcTemplate.update("UPDATE notifications SET is_read = TRUE WHERE user_id = ?", userId);
    }
}
