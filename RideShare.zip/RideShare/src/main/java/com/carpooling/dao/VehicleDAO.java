package com.carpooling.dao;

import com.carpooling.model.Vehicle;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public class VehicleDAO {

    private final JdbcTemplate jdbcTemplate;

    public VehicleDAO(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    private static final RowMapper<Vehicle> VEHICLE_MAPPER = (rs, rowNum) -> {
        Vehicle v = new Vehicle();
        v.setId(rs.getLong("vehicle_id"));
        v.setUserId(rs.getLong("user_id"));
        v.setVehicleNumber(rs.getString("vehicle_number"));
        v.setModel(rs.getString("model"));
        v.setVehicleType(rs.getString("vehicle_type"));
        v.setColor(rs.getString("color"));
        v.setSeats(rs.getInt("seats"));
        return v;
    };

    public Long insert(Vehicle vehicle) {
        String sql = "INSERT INTO vehicles (user_id, vehicle_number, model, vehicle_type, color, seats) VALUES (?, ?, ?, ?, ?, ?)";
        jdbcTemplate.update(sql, vehicle.getUserId(), vehicle.getVehicleNumber(), vehicle.getModel(),
                vehicle.getVehicleType(), vehicle.getColor(), vehicle.getSeats());
        Long id = jdbcTemplate.queryForObject(
                "SELECT vehicle_id FROM vehicles WHERE user_id = ? AND vehicle_number = ?",
                Long.class, vehicle.getUserId(), vehicle.getVehicleNumber());
        if (id == null) throw new IllegalStateException("Vehicle was added but its ID could not be retrieved.");
        return id;
    }

    public List<Vehicle> findByUserId(Long userId) {
        String sql = "SELECT * FROM vehicles WHERE user_id = ? ORDER BY vehicle_id DESC";
        return jdbcTemplate.query(sql, VEHICLE_MAPPER, userId);
    }

    public Optional<Vehicle> findById(Long id) {
        String sql = "SELECT * FROM vehicles WHERE vehicle_id = ?";
        return jdbcTemplate.query(sql, VEHICLE_MAPPER, id).stream().findFirst();
    }

    public void update(Vehicle vehicle) {
        String sql = "UPDATE vehicles SET vehicle_number = ?, model = ?, vehicle_type = ?, color = ?, seats = ? WHERE vehicle_id = ? AND user_id = ?";
        jdbcTemplate.update(sql, vehicle.getVehicleNumber(), vehicle.getModel(), vehicle.getVehicleType(),
                vehicle.getColor(), vehicle.getSeats(), vehicle.getId(), vehicle.getUserId());
    }

    public void delete(Long vehicleId, Long userId) {
        jdbcTemplate.update("DELETE FROM vehicles WHERE vehicle_id = ? AND user_id = ?", vehicleId, userId);
    }

    public long countAll() {
        Long count = jdbcTemplate.queryForObject("SELECT COUNT(*) FROM vehicles", Long.class);
        return count == null ? 0 : count;
    }
}
