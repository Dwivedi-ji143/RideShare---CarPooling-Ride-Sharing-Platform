package com.carpooling.service;

import com.carpooling.dao.NotificationDAO;
import com.carpooling.model.Notification;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class NotificationService {

    private final NotificationDAO notificationDAO;

    public NotificationService(NotificationDAO notificationDAO) {
        this.notificationDAO = notificationDAO;
    }

    public void notify(Long userId, String message, String type) {
        notificationDAO.insert(userId, message, type);
    }

    public List<Notification> getForUser(Long userId) {
        return notificationDAO.findByUserId(userId);
    }

    public long unreadCount(Long userId) {
        return notificationDAO.countUnread(userId);
    }

    public void markRead(Long notificationId) {
        notificationDAO.markRead(notificationId);
    }

    public void markAllRead(Long userId) {
        notificationDAO.markAllRead(userId);
    }
}
