package com.carpooling.service;

import com.carpooling.dao.RatingDAO;
import com.carpooling.model.Rating;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
public class RatingService {

    private final RatingDAO ratingDAO;

    public RatingService(RatingDAO ratingDAO) {
        this.ratingDAO = ratingDAO;
    }

    public void rateDriver(Long rideId, Long driverId, Long passengerId, int stars, String review) {
        if (stars < 1 || stars > 5) throw new IllegalArgumentException("Rating must be between 1 and 5 stars.");
        if (ratingDAO.alreadyRated(rideId, passengerId)) {
            throw new IllegalStateException("You have already rated this ride.");
        }
        Rating rating = new Rating();
        rating.setRideId(rideId);
        rating.setDriverId(driverId);
        rating.setPassengerId(passengerId);
        rating.setRating(stars);
        rating.setReview(review);
        ratingDAO.insert(rating);
    }

    public List<Rating> findByDriverId(Long driverId) {
        return ratingDAO.findByDriverId(driverId);
    }

    public Map<String, Object> summaryForDriver(Long driverId) {
        return ratingDAO.summaryForDriver(driverId);
    }
}
