package com.carpooling.service;

import com.carpooling.dao.ReportDAO;
import com.carpooling.model.Report;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ReportService {

    private final ReportDAO reportDAO;

    public ReportService(ReportDAO reportDAO) {
        this.reportDAO = reportDAO;
    }

    public void fileReport(Long reportedBy, Long reportedUser, Long rideId, String reason, String description) {
        if (reason == null || reason.isBlank()) throw new IllegalArgumentException("Please select a reason.");
        if (reason.trim().length() > 100) throw new IllegalArgumentException("Report reason is too long.");
        if (description != null && description.length() > 1000) throw new IllegalArgumentException("Description must be 1000 characters or less.");
        if (reportedBy == null) throw new IllegalArgumentException("You must be signed in to submit a report.");
        Report report = new Report();
        report.setReportedBy(reportedBy);
        report.setReportedUser(reportedUser);
        report.setRideId(rideId);
        report.setReason(reason);
        report.setDescription(description);
        reportDAO.insert(report);
    }

    public List<Report> findAll() {
        return reportDAO.findAll();
    }

    public void updateStatus(Long reportId, String status) {
        reportDAO.updateStatus(reportId, status);
    }

    public long countOpen() { return reportDAO.countOpen(); }
}
