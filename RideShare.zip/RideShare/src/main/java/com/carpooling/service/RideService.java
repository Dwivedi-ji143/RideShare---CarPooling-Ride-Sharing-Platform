package com.carpooling.service;

import com.carpooling.dao.RideDAO;
import com.carpooling.dao.VehicleDAO;
import com.carpooling.model.Ride;
import com.carpooling.model.Vehicle;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@Service
public class RideService {

    private final RideDAO rideDAO;
    private final VehicleDAO vehicleDAO;

    public RideService(RideDAO rideDAO, VehicleDAO vehicleDAO) {
        this.rideDAO = rideDAO;
        this.vehicleDAO = vehicleDAO;
    }

    public Long offerRide(Long driverId, Long vehicleId, String source, String destination,
                           LocalDate date, LocalTime time, int seats,
                           BigDecimal distanceKm, BigDecimal fuelCost, BigDecimal tollCost, String notes) {

        if (source == null || source.isBlank() || destination == null || destination.isBlank()) {
            throw new IllegalArgumentException("Source and destination are required.");
        }
        if (source.trim().equalsIgnoreCase(destination.trim())) {
            throw new IllegalArgumentException("Source and destination cannot be the same.");
        }
        if (date == null || date.isBefore(LocalDate.now())) {
            throw new IllegalArgumentException("Departure date must be today or later.");
        }
        if (time == null) {
            throw new IllegalArgumentException("Departure time is required.");
        }
        if (date != null && date.equals(LocalDate.now()) && time.isBefore(LocalTime.now())) {
            throw new IllegalArgumentException("For today's ride, departure time must be in the future.");
        }
        if (distanceKm != null && distanceKm.signum() < 0) {
            throw new IllegalArgumentException("Distance cannot be negative.");
        }
        if (fuelCost != null && fuelCost.signum() < 0) {
            throw new IllegalArgumentException("Fuel cost cannot be negative.");
        }
        if (tollCost != null && tollCost.signum() < 0) {
            throw new IllegalArgumentException("Toll cost cannot be negative.");
        }
        Vehicle vehicle = vehicleDAO.findById(vehicleId)
                .orElseThrow(() -> new IllegalArgumentException("Selected vehicle not found."));
        if (!vehicle.getUserId().equals(driverId)) {
            throw new IllegalArgumentException("You can only offer rides using your own vehicle.");
        }
        if (seats < 1 || seats > vehicle.getSeats()) {
            throw new IllegalArgumentException("Available seats must be between 1 and " + vehicle.getSeats() + ".");
        }

        Ride ride = new Ride();
        ride.setDriverId(driverId);
        ride.setVehicleId(vehicleId);
        ride.setSource(source.trim());
        ride.setDestination(destination.trim());
        ride.setDepartureDate(date);
        ride.setDepartureTime(time);
        ride.setAvailableSeats(seats);
        ride.setTotalSeats(seats);
        ride.setDistanceKm(distanceKm == null ? BigDecimal.ZERO : distanceKm);
        ride.setFuelCost(fuelCost == null ? BigDecimal.ZERO : fuelCost);
        ride.setTollCost(tollCost == null ? BigDecimal.ZERO : tollCost);
        ride.setNotes(notes == null ? null : notes.trim());

        return rideDAO.insert(ride);
    }

    public List<Ride> search(String source, String destination, LocalDate date, int seats,
                              BigDecimal maxCost, Double minRating, String vehicleType) {
        List<Ride> results = rideDAO.search(source, destination, date, seats, maxCost, minRating, vehicleType);
        // Attach a simple route-compatibility score (Section 5.12) relative to the searched route.
        for (Ride r : results) {
            r.setRouteCompatibility(computeCompatibility(source, destination, r.getSource(), r.getDestination()));
        }
        return results;
    }

    /**
     * Simple route compatibility heuristic: exact source+destination match scores highest;
     * partial (one-side) matches score lower. This is the "basic" version described in the
     * spec — later phases can swap this for a real routing/map API.
     */
    private int computeCompatibility(String reqSource, String reqDest, String rideSource, String rideDest) {
        boolean sourceMatch = reqSource != null && rideSource.toLowerCase().contains(reqSource.toLowerCase());
        boolean destMatch = reqDest != null && rideDest.toLowerCase().contains(reqDest.toLowerCase());
        if (sourceMatch && destMatch) return 95;
        if (destMatch) return 75; // same destination, different pickup point along the way
        if (sourceMatch) return 60;
        return 40;
    }

    public Optional<Ride> findById(Long id) {
        return rideDAO.findById(id);
    }

    public List<Ride> findByDriverId(Long driverId) {
        return rideDAO.findByDriverId(driverId);
    }

    public void cancelRide(Long rideId, Long driverId) {
        Ride ride = rideDAO.findById(rideId).orElseThrow(() -> new IllegalArgumentException("Ride not found."));
        if (!ride.getDriverId().equals(driverId)) throw new IllegalArgumentException("Not authorized to cancel this ride.");
        rideDAO.updateStatus(rideId, "CANCELLED");
    }

    public void completeRide(Long rideId, Long driverId) {
        Ride ride = rideDAO.findById(rideId).orElseThrow(() -> new IllegalArgumentException("Ride not found."));
        if (!ride.getDriverId().equals(driverId)) throw new IllegalArgumentException("Not authorized to complete this ride.");
        rideDAO.updateStatus(rideId, "COMPLETED");
    }

    public void updateRide(Ride ride) {
        rideDAO.update(ride);
    }

    public long countAll() { return rideDAO.countAll(); }
    public long countByStatus(String status) { return rideDAO.countByStatus(status); }
    public List<Map<String, Object>> popularRoutes(int limit) { return rideDAO.popularRoutes(limit); }
}
