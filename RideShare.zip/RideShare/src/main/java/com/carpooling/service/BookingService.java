package com.carpooling.service;

import com.carpooling.dao.BookingDAO;
import com.carpooling.dao.RideDAO;
import com.carpooling.model.Booking;
import com.carpooling.model.Ride;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

@Service
public class BookingService {

    private final BookingDAO bookingDAO;
    private final RideDAO rideDAO;
    private final NotificationService notificationService;

    public BookingService(BookingDAO bookingDAO, RideDAO rideDAO, NotificationService notificationService) {
        this.bookingDAO = bookingDAO;
        this.rideDAO = rideDAO;
        this.notificationService = notificationService;
    }

    /**
     * Books seats on a ride inside a single DB transaction:
     *  1. Atomically decrement available_seats (WHERE available_seats >= requested) — this is what
     *     actually prevents overbooking under concurrent requests, not just an app-level check.
     *  2. If the decrement affected 0 rows, another booking beat us to the last seats — fail cleanly.
     *  3. Otherwise insert the booking row and notify both parties.
     */
    @Transactional
    public Long book(Long rideId, Long passengerId, int seatsRequested) {
        if (seatsRequested < 1 || seatsRequested > 8) throw new IllegalArgumentException("Seats must be between 1 and 8.");

        Ride ride = rideDAO.findById(rideId)
                .orElseThrow(() -> new IllegalArgumentException("Ride not found."));

        if (!"ACTIVE".equals(ride.getStatus())) {
            throw new IllegalStateException("This ride is no longer available.");
        }
        if (ride.getDriverId().equals(passengerId)) {
            throw new IllegalArgumentException("You cannot book your own ride.");
        }
        if (bookingDAO.existsConfirmed(rideId, passengerId)) {
            throw new IllegalStateException("You already have a confirmed booking for this ride.");
        }

        boolean seatsReserved = rideDAO.decrementSeats(rideId, seatsRequested);
        if (!seatsReserved) {
            throw new IllegalStateException("Not enough seats available. Please try fewer seats.");
        }

        BigDecimal amount = ride.getCostPerPerson().multiply(BigDecimal.valueOf(seatsRequested));

        Booking booking = new Booking();
        booking.setRideId(rideId);
        booking.setPassengerId(passengerId);
        booking.setSeatsBooked(seatsRequested);
        booking.setAmount(amount);

        Long bookingId = bookingDAO.insert(booking);

        notificationService.notify(passengerId,
                "Your booking for " + ride.getSource() + " -> " + ride.getDestination() + " is confirmed.",
                "BOOKING_CONFIRMED");
        notificationService.notify(ride.getDriverId(),
                "A new passenger booked " + seatsRequested + " seat(s) on your ride.",
                "NEW_PASSENGER");

        return bookingId;
    }

    @Transactional
    public void cancel(Long bookingId, Long passengerId) {
        Booking booking = bookingDAO.findById(bookingId)
                .orElseThrow(() -> new IllegalArgumentException("Booking not found."));
        if (!booking.getPassengerId().equals(passengerId)) {
            throw new IllegalArgumentException("Not authorized to cancel this booking.");
        }
        if (!"CONFIRMED".equals(booking.getStatus())) {
            throw new IllegalStateException("This booking cannot be cancelled.");
        }

        bookingDAO.updateStatus(bookingId, "CANCELLED");
        rideDAO.incrementSeats(booking.getRideId(), booking.getSeatsBooked());

        notificationService.notify(passengerId,
                "Your booking for " + booking.getSource() + " -> " + booking.getDestination() + " was cancelled.",
                "BOOKING_CANCELLED");
    }

    public List<Booking> findByPassengerId(Long passengerId) {
        return bookingDAO.findByPassengerId(passengerId);
    }

    public List<Booking> findByRideId(Long rideId) {
        return bookingDAO.findByRideId(rideId);
    }

    public Optional<Booking> findById(Long id) {
        return bookingDAO.findById(id);
    }

    public long countAll() { return bookingDAO.countAll(); }
}
