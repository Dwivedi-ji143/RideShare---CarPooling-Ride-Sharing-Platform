package com.carpooling.service;

import com.carpooling.dao.VehicleDAO;
import com.carpooling.model.Vehicle;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class VehicleService {

    private final VehicleDAO vehicleDAO;

    public VehicleService(VehicleDAO vehicleDAO) {
        this.vehicleDAO = vehicleDAO;
    }

    public Long addVehicle(Long userId, String vehicleNumber, String model, String vehicleType, String color, int seats) {
        if (vehicleNumber == null || vehicleNumber.isBlank()) throw new IllegalArgumentException("Vehicle number is required.");
        vehicleNumber = vehicleNumber.trim().toUpperCase();
        if (model == null || model.isBlank()) throw new IllegalArgumentException("Vehicle model is required.");
        if (seats < 1 || seats > 8) throw new IllegalArgumentException("Seats must be between 1 and 8.");

        Vehicle v = new Vehicle();
        v.setUserId(userId);
        v.setVehicleNumber(vehicleNumber);
        v.setModel(model.trim());
        if (vehicleType == null || vehicleType.isBlank()) throw new IllegalArgumentException("Vehicle type is required.");
        if (!java.util.Set.of("HATCHBACK", "SEDAN", "SUV", "BIKE", "OTHER").contains(vehicleType)) {
            throw new IllegalArgumentException("Invalid vehicle type.");
        }
        v.setVehicleType(vehicleType.trim().toUpperCase());
        v.setColor(color == null ? null : color.trim());
        v.setSeats(seats);
        return vehicleDAO.insert(v);
    }

    public List<Vehicle> getVehiclesForUser(Long userId) {
        return vehicleDAO.findByUserId(userId);
    }

    public Optional<Vehicle> findById(Long id) {
        return vehicleDAO.findById(id);
    }

    public void updateVehicle(Vehicle vehicle) {
        if (vehicle == null || vehicle.getId() == null || vehicle.getUserId() == null) {
            throw new IllegalArgumentException("Invalid vehicle details.");
        }
        if (vehicle.getVehicleNumber() == null || vehicle.getVehicleNumber().isBlank()) {
            throw new IllegalArgumentException("Vehicle number is required.");
        }
        if (vehicle.getModel() == null || vehicle.getModel().isBlank()) {
            throw new IllegalArgumentException("Vehicle model is required.");
        }
        if (!java.util.Set.of("HATCHBACK", "SEDAN", "SUV", "BIKE", "OTHER")
                .contains(vehicle.getVehicleType() == null ? "" : vehicle.getVehicleType().trim().toUpperCase())) {
            throw new IllegalArgumentException("Invalid vehicle type.");
        }
        if (vehicle.getSeats() < 1 || vehicle.getSeats() > 8) {
            throw new IllegalArgumentException("Seats must be between 1 and 8.");
        }
        vehicle.setVehicleNumber(vehicle.getVehicleNumber().trim().toUpperCase());
        vehicle.setModel(vehicle.getModel().trim());
        vehicle.setVehicleType(vehicle.getVehicleType().trim().toUpperCase());
        vehicle.setColor(vehicle.getColor() == null ? null : vehicle.getColor().trim());
        vehicleDAO.update(vehicle);
    }

    public void deleteVehicle(Long vehicleId, Long userId) {
        vehicleDAO.delete(vehicleId, userId);
    }

    public long countAll() { return vehicleDAO.countAll(); }
}
