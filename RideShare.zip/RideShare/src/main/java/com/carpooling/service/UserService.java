package com.carpooling.service;

import com.carpooling.dao.UserDAO;
import com.carpooling.model.User;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.regex.Pattern;

@Service
public class UserService {

    private static final Pattern EMAIL_PATTERN = Pattern.compile("^[\\w.+-]+@[\\w-]+\\.[a-zA-Z]{2,}$");
    private static final Pattern PHONE_PATTERN = Pattern.compile("^[6-9]\\d{9}$");

    private final UserDAO userDAO;
    private final BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();

    public UserService(UserDAO userDAO) {
        this.userDAO = userDAO;
    }

    public Long register(String name, String email, String phone, String password, String confirmPassword,
                         String city, String role) {
        name = name == null ? "" : name.trim();
        email = email == null ? "" : email.trim().toLowerCase();
        phone = phone == null ? "" : phone.trim();
        city = city == null ? null : city.trim();
        role = role == null ? "" : role.trim().toUpperCase();

        if (name.isBlank()) throw new IllegalArgumentException("Full name is required.");
        if (name.length() > 100) throw new IllegalArgumentException("Full name must be 100 characters or less.");
        if (!EMAIL_PATTERN.matcher(email).matches()) throw new IllegalArgumentException("Enter a valid email address.");
        if (email.length() > 150) throw new IllegalArgumentException("Email must be 150 characters or less.");
        if (!PHONE_PATTERN.matcher(phone).matches()) throw new IllegalArgumentException("Enter a valid 10-digit phone number.");
        if (password == null || password.length() < 8) throw new IllegalArgumentException("Password must be at least 8 characters.");
        if (!password.equals(confirmPassword)) throw new IllegalArgumentException("Passwords do not match.");
        if (!role.equals("PASSENGER") && !role.equals("DRIVER")) throw new IllegalArgumentException("Select a valid role.");

        // Application-level check for a fast, friendly error. The DB UNIQUE constraints
        // remain the final protection against duplicate accounts during concurrent requests.
        if (userDAO.existsByEmail(email)) throw new IllegalArgumentException("An account with this email already exists.");
        if (userDAO.existsByPhone(phone)) throw new IllegalArgumentException("An account with this phone number already exists.");

        User user = new User();
        user.setName(name);
        user.setEmail(email);
        user.setPhone(phone);
        user.setPassword(passwordEncoder.encode(password));
        user.setRole(role);
        user.setCity(city);

        return userDAO.insert(user);
    }

    public Optional<User> authenticate(String email, String rawPassword) {
        if (email == null || rawPassword == null) return Optional.empty();
        Optional<User> userOpt = userDAO.findByEmail(email.trim().toLowerCase());
        if (userOpt.isEmpty()) return Optional.empty();
        User user = userOpt.get();
        if (!passwordEncoder.matches(rawPassword, user.getPassword())) return Optional.empty();
        if ("SUSPENDED".equals(user.getStatus())) return Optional.empty();
        return Optional.of(user);
    }

    public Optional<User> findById(Long id) { return userDAO.findById(id); }

    public void updateProfile(User user) {
        if (user.getName() == null || user.getName().isBlank()) throw new IllegalArgumentException("Name is required.");
        if (user.getPhone() == null || !PHONE_PATTERN.matcher(user.getPhone().trim()).matches()) {
            throw new IllegalArgumentException("Enter a valid 10-digit phone number.");
        }
        user.setName(user.getName().trim());
        user.setPhone(user.getPhone().trim());
        user.setCity(user.getCity() == null ? null : user.getCity().trim());
        userDAO.updateProfile(user);
    }

    public void changePassword(Long userId, String currentPassword, String newPassword) {
        User user = userDAO.findById(userId).orElseThrow(() -> new IllegalArgumentException("User not found."));
        if (!passwordEncoder.matches(currentPassword, user.getPassword())) {
            throw new IllegalArgumentException("Current password is incorrect.");
        }
        if (newPassword == null || newPassword.length() < 8) {
            throw new IllegalArgumentException("New password must be at least 8 characters.");
        }
        userDAO.updatePassword(userId, passwordEncoder.encode(newPassword));
    }

    public void updateProfileImage(Long userId, String path) { userDAO.updateProfileImage(userId, path); }
    public List<User> findAll() { return userDAO.findAll(); }
    public void suspend(Long userId) { userDAO.updateStatus(userId, "SUSPENDED"); }
    public void reactivate(Long userId) { userDAO.updateStatus(userId, "ACTIVE"); }
    public long countPassengers() { return userDAO.countByRole("PASSENGER"); }
    public long countDrivers() { return userDAO.countByRole("DRIVER"); }
}
