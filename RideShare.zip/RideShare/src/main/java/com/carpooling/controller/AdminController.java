package com.carpooling.controller;

import com.carpooling.service.*;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@Controller
@RequestMapping("/admin")
public class AdminController {

    private final UserService userService;
    private final RideService rideService;
    private final BookingService bookingService;
    private final VehicleService vehicleService;
    private final ReportService reportService;

    public AdminController(UserService userService, RideService rideService, BookingService bookingService,
                            VehicleService vehicleService, ReportService reportService) {
        this.userService = userService;
        this.rideService = rideService;
        this.bookingService = bookingService;
        this.vehicleService = vehicleService;
        this.reportService = reportService;
    }

    /** Every /admin/** route checks the session role — a simple, explicit alternative to Spring Security. */
    private boolean isAdmin(HttpSession session) {
        return "ADMIN".equals(session.getAttribute("userRole"));
    }

    @GetMapping("/dashboard")
    public String dashboard(HttpSession session, Model model) {
        if (!isAdmin(session)) return "redirect:/login";

        Map<String, Object> stats = new HashMap<>();
        stats.put("totalPassengers", userService.countPassengers());
        stats.put("totalDrivers", userService.countDrivers());
        stats.put("totalVehicles", vehicleService.countAll());
        stats.put("totalRides", rideService.countAll());
        stats.put("activeRides", rideService.countByStatus("ACTIVE"));
        stats.put("completedRides", rideService.countByStatus("COMPLETED"));
        stats.put("cancelledRides", rideService.countByStatus("CANCELLED"));
        stats.put("totalBookings", bookingService.countAll());
        stats.put("openReports", reportService.countOpen());

        model.addAttribute("stats", stats);
        model.addAttribute("popularRoutes", rideService.popularRoutes(5));
        return "admin/dashboard";
    }

    @GetMapping("/users")
    public String users(HttpSession session, Model model) {
        if (!isAdmin(session)) return "redirect:/login";
        model.addAttribute("users", userService.findAll());
        return "admin/users";
    }

    @PostMapping("/users/{id}/suspend")
    public String suspendUser(@PathVariable Long id, HttpSession session) {
        if (!isAdmin(session)) return "redirect:/login";
        userService.suspend(id);
        return "redirect:/admin/users";
    }

    @PostMapping("/users/{id}/reactivate")
    public String reactivateUser(@PathVariable Long id, HttpSession session) {
        if (!isAdmin(session)) return "redirect:/login";
        userService.reactivate(id);
        return "redirect:/admin/users";
    }

    @GetMapping("/reports")
    public String reports(HttpSession session, Model model) {
        if (!isAdmin(session)) return "redirect:/login";
        model.addAttribute("reports", reportService.findAll());
        return "admin/reports";
    }

    @PostMapping("/reports/{id}/resolve")
    public String resolveReport(@PathVariable Long id, HttpSession session) {
        if (!isAdmin(session)) return "redirect:/login";
        reportService.updateStatus(id, "RESOLVED");
        return "redirect:/admin/reports";
    }
}
