package com.carpooling.controller;

import com.carpooling.model.Ride;
import com.carpooling.service.RideService;
import com.carpooling.service.VehicleService;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

@Controller
public class RideController {

    private final RideService rideService;
    private final VehicleService vehicleService;

    public RideController(RideService rideService, VehicleService vehicleService) {
        this.rideService = rideService;
        this.vehicleService = vehicleService;
    }

    // ---------- Offer Ride (Driver) ----------

    @GetMapping("/offer-ride")
    public String offerRideForm(HttpSession session, Model model) {
        Long userId = (Long) session.getAttribute("userId");
        if (userId == null) return "redirect:/login";
        if (!"DRIVER".equals(session.getAttribute("userRole"))) return "redirect:/dashboard";
        model.addAttribute("vehicles", vehicleService.getVehiclesForUser(userId));
        return "offer-ride";
    }

    @PostMapping("/offer-ride")
    public String offerRide(@RequestParam Long vehicleId, @RequestParam String source,
                             @RequestParam String destination,
                             @RequestParam @org.springframework.format.annotation.DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate date,
                             @RequestParam @org.springframework.format.annotation.DateTimeFormat(pattern = "HH:mm") LocalTime time,
                             @RequestParam int seats, @RequestParam(required = false) BigDecimal distanceKm,
                             @RequestParam(required = false) BigDecimal fuelCost,
                             @RequestParam(required = false) BigDecimal tollCost,
                             @RequestParam(required = false) String notes,
                             HttpSession session, Model model) {
        Long userId = (Long) session.getAttribute("userId");
        if (userId == null) return "redirect:/login";
        if (!"DRIVER".equals(session.getAttribute("userRole"))) return "redirect:/dashboard";
        try {
            Long rideId = rideService.offerRide(userId, vehicleId, source, destination, date, time,
                    seats, distanceKm, fuelCost, tollCost, notes);
            return "redirect:/ride/" + rideId;
        } catch (IllegalArgumentException ex) {
            model.addAttribute("error", ex.getMessage());
            model.addAttribute("vehicles", vehicleService.getVehiclesForUser(userId));
            return "offer-ride";
        }
    }

    @GetMapping("/my-rides")
    public String myRides(HttpSession session, Model model) {
        Long userId = (Long) session.getAttribute("userId");
        if (userId == null) return "redirect:/login";
        model.addAttribute("rides", rideService.findByDriverId(userId));
        return "my-rides";
    }

    @PostMapping("/ride/{id}/cancel")
    public String cancelRide(@PathVariable Long id, HttpSession session) {
        Long userId = (Long) session.getAttribute("userId");
        if (userId == null) return "redirect:/login";
        rideService.cancelRide(id, userId);
        return "redirect:/my-rides";
    }

    @PostMapping("/ride/{id}/complete")
    public String completeRide(@PathVariable Long id, HttpSession session) {
        Long userId = (Long) session.getAttribute("userId");
        if (userId == null) return "redirect:/login";
        rideService.completeRide(id, userId);
        return "redirect:/my-rides";
    }

    // ---------- Search (Passenger) ----------

    @GetMapping("/search-rides")
    public String searchForm() {
        return "search-rides";
    }

    @GetMapping("/search-rides/results")
    public String search(@RequestParam(required = false) String source,
                          @RequestParam(required = false) String destination,
                          @RequestParam(required = false) @org.springframework.format.annotation.DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate date,
                          @RequestParam(defaultValue = "1") int seats,
                          @RequestParam(required = false) BigDecimal maxCost,
                          @RequestParam(required = false) Double minRating,
                          @RequestParam(required = false) String vehicleType,
                          Model model) {
        List<Ride> rides = rideService.search(source, destination, date, seats, maxCost, minRating, vehicleType);
        model.addAttribute("rides", rides);
        model.addAttribute("source", source);
        model.addAttribute("destination", destination);
        model.addAttribute("date", date);
        model.addAttribute("seats", seats);
        return "search-rides";
    }

    // ---------- Ride Details ----------

    @GetMapping("/ride/{id}")
    public String rideDetails(@PathVariable Long id, Model model) {
        Ride ride = rideService.findById(id).orElseThrow(() -> new IllegalArgumentException("Ride not found."));
        model.addAttribute("ride", ride);
        return "ride-details";
    }
}
