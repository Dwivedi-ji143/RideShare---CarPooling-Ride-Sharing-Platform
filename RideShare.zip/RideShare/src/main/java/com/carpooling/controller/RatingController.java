package com.carpooling.controller;

import com.carpooling.service.RatingService;
import com.carpooling.service.ReportService;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class RatingController {

    private final RatingService ratingService;
    private final ReportService reportService;

    public RatingController(RatingService ratingService, ReportService reportService) {
        this.ratingService = ratingService;
        this.reportService = reportService;
    }

    @PostMapping("/ride/{rideId}/rate")
    public String rate(@PathVariable Long rideId, @RequestParam Long driverId,
                        @RequestParam int stars, @RequestParam(required = false) String review,
                        HttpSession session, Model model) {
        Long userId = (Long) session.getAttribute("userId");
        if (userId == null) return "redirect:/login";
        try {
            ratingService.rateDriver(rideId, driverId, userId, stars, review);
        } catch (IllegalArgumentException | IllegalStateException ex) {
            model.addAttribute("error", ex.getMessage());
        }
        return "redirect:/bookings";
    }

    @GetMapping("/report")
    public String reportForm(HttpSession session) {
        if (session.getAttribute("userId") == null) return "redirect:/login";
        return "report-issue";
    }

    @PostMapping("/report")
    public String submitReport(@RequestParam(required = false) Long reportedUser,
                                @RequestParam(required = false) Long rideId,
                                @RequestParam String reason, @RequestParam(required = false) String description,
                                HttpSession session, Model model) {
        Long userId = (Long) session.getAttribute("userId");
        if (userId == null) return "redirect:/login";
        try {
            reportService.fileReport(userId, reportedUser, rideId, reason, description);
            model.addAttribute("success", "Your report has been submitted. Our team will review it shortly.");
        } catch (IllegalArgumentException ex) {
            model.addAttribute("error", ex.getMessage());
        }
        return "report-issue";
    }
}
