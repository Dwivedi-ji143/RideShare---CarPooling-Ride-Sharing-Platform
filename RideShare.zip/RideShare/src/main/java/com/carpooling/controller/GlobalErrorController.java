package com.carpooling.controller;

import jakarta.servlet.http.HttpServletRequest;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class GlobalErrorController {

    @ExceptionHandler(Exception.class)
    public String handleException(Exception ex, HttpServletRequest request, Model model) {
        ex.printStackTrace();
        model.addAttribute("errorMessage", "The requested operation could not be completed.");
        model.addAttribute("requestPath", request.getRequestURI());
        return "error";
    }
}
