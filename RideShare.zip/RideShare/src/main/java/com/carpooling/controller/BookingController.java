package com.carpooling.controller;

import com.carpooling.model.Booking;
import com.carpooling.model.Ride;
import com.carpooling.service.BookingService;
import com.carpooling.service.RideService;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
public class BookingController {

    private final BookingService bookingService;
    private final RideService rideService;

    public BookingController(BookingService bookingService, RideService rideService) {
        this.bookingService = bookingService;
        this.rideService = rideService;
    }

    @PostMapping("/ride/{id}/book")
    public String book(@PathVariable Long id, @RequestParam(defaultValue = "1") int seats,
                        HttpSession session, Model model) {
        Long userId = (Long) session.getAttribute("userId");
        if (userId == null) return "redirect:/login";

        try {
            Long bookingId = bookingService.book(id, userId, seats);
            return "redirect:/booking/" + bookingId + "/confirmation";
        } catch (IllegalArgumentException | IllegalStateException ex) {
            Ride ride = rideService.findById(id).orElseThrow();
            model.addAttribute("ride", ride);
            model.addAttribute("error", ex.getMessage());
            return "ride-details";
        }
    }

    @GetMapping("/booking/{id}/confirmation")
    public String confirmation(@PathVariable Long id, HttpSession session, Model model) {
        if (session.getAttribute("userId") == null) return "redirect:/login";
        Booking booking = bookingService.findById(id).orElseThrow(() -> new IllegalArgumentException("Booking not found."));
        model.addAttribute("booking", booking);
        return "booking-confirmation";
    }

    @GetMapping("/bookings")
    public String myBookings(HttpSession session, Model model) {
        Long userId = (Long) session.getAttribute("userId");
        if (userId == null) return "redirect:/login";
        model.addAttribute("bookings", bookingService.findByPassengerId(userId));
        return "bookings";
    }

    @PostMapping("/booking/{id}/cancel")
    public String cancel(@PathVariable Long id, HttpSession session, RedirectAttributes redirectAttributes) {
        Long userId = (Long) session.getAttribute("userId");
        if (userId == null) return "redirect:/login";
        try {
            bookingService.cancel(id, userId);
        } catch (IllegalArgumentException | IllegalStateException ex) {
            redirectAttributes.addFlashAttribute("error", ex.getMessage());
        }
        return "redirect:/bookings";
    }
}
