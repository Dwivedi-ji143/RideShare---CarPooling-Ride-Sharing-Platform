package com.carpooling.controller;

import com.carpooling.model.User;
import com.carpooling.service.UserService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.Optional;

@Controller
public class AuthController {

    private final UserService userService;

    public AuthController(UserService userService) {
        this.userService = userService;
    }

    @GetMapping("/")
    public String landing() {
        return "index";
    }

    @GetMapping("/login")
    public String loginForm(HttpSession session) {
        if (session.getAttribute("userId") != null) return "redirect:/dashboard";
        return "login";
    }

    @PostMapping("/login")
    public String login(@RequestParam String email,
                        @RequestParam String password,
                        HttpServletRequest request,
                        Model model) {
        String normalizedEmail = email == null ? "" : email.trim().toLowerCase();
        Optional<User> userOpt;
        try {
            userOpt = userService.authenticate(normalizedEmail, password);
        } catch (DataAccessException ex) {
            ex.printStackTrace();
            model.addAttribute("error", "Unable to connect to the database. Please start MySQL and try again.");
            model.addAttribute("email", normalizedEmail);
            return "login";
        }

        if (userOpt.isEmpty()) {
            model.addAttribute("error", "Invalid email or password, or your account has been suspended.");
            model.addAttribute("email", normalizedEmail);
            return "login";
        }

        User user = userOpt.get();

        // Prevent session fixation by replacing the old session after authentication.
        HttpSession oldSession = request.getSession(false);
        if (oldSession != null) oldSession.invalidate();
        HttpSession session = request.getSession(true);
        session.setAttribute("userId", user.getId());
        session.setAttribute("userRole", user.getRole());
        session.setAttribute("userName", user.getName());

        return "ADMIN".equals(user.getRole())
                ? "redirect:/admin/dashboard"
                : "redirect:/dashboard";
    }

    @GetMapping("/register")
    public String registerForm(HttpSession session) {
        if (session.getAttribute("userId") != null) return "redirect:/dashboard";
        return "register";
    }

    @PostMapping("/register")
    public String register(@RequestParam String name,
                           @RequestParam String email,
                           @RequestParam String phone,
                           @RequestParam String password,
                           @RequestParam String confirmPassword,
                           @RequestParam(required = false) String city,
                           @RequestParam String role,
                           HttpSession session,
                           Model model) {
        String normalizedEmail = email == null ? "" : email.trim().toLowerCase();
        String normalizedPhone = phone == null ? "" : phone.trim();
        String normalizedRole = role == null ? "" : role.trim().toUpperCase();

        try {
            Long userId = userService.register(
                    name,
                    normalizedEmail,
                    normalizedPhone,
                    password,
                    confirmPassword,
                    city,
                    normalizedRole
            );

            session.setAttribute("userId", userId);
            session.setAttribute("userRole", normalizedRole);
            session.setAttribute("userName", name.trim());
            return "redirect:/dashboard";
        } catch (IllegalArgumentException | DataIntegrityViolationException ex) {
            String message = ex instanceof DataIntegrityViolationException
                    ? "An account with this email or phone number already exists."
                    : ex.getMessage();
            model.addAttribute("error", message);
            model.addAttribute("name", name);
            model.addAttribute("email", normalizedEmail);
            model.addAttribute("phone", normalizedPhone);
            model.addAttribute("city", city);
            model.addAttribute("role", normalizedRole);
            return "register";
        } catch (DataAccessException ex) {
            ex.printStackTrace();
            model.addAttribute("error", "Registration could not be completed. Please verify that MySQL is running and the carpooling_db database is available.");
            model.addAttribute("name", name);
            model.addAttribute("email", normalizedEmail);
            model.addAttribute("phone", normalizedPhone);
            model.addAttribute("city", city);
            model.addAttribute("role", normalizedRole);
            return "register";
        } catch (Exception ex) {
            ex.printStackTrace();
            model.addAttribute("error", "Something went wrong while creating the account. Please try again.");
            model.addAttribute("name", name);
            model.addAttribute("email", normalizedEmail);
            model.addAttribute("phone", normalizedPhone);
            model.addAttribute("city", city);
            model.addAttribute("role", normalizedRole);
            return "register";
        }
    }

    @GetMapping("/logout")
    public String logout(HttpSession session) {
        session.invalidate();
        return "redirect:/";
    }
}
