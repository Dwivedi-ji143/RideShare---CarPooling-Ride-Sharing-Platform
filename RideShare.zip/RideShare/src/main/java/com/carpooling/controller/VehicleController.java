package com.carpooling.controller;

import com.carpooling.model.Vehicle;
import com.carpooling.service.VehicleService;
import jakarta.servlet.http.HttpSession;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/vehicle")
public class VehicleController {

    private final VehicleService vehicleService;

    public VehicleController(VehicleService vehicleService) {
        this.vehicleService = vehicleService;
    }

    @GetMapping
    public String myVehicles(HttpSession session, Model model) {
        Long userId = (Long) session.getAttribute("userId");
        if (userId == null) return "redirect:/login";
        if (!"DRIVER".equals(session.getAttribute("userRole"))) return "redirect:/dashboard";
        model.addAttribute("vehicles", vehicleService.getVehiclesForUser(userId));
        return "vehicle";
    }

    @PostMapping("/add")
    public String add(@RequestParam String vehicleNumber, @RequestParam String model_,
                       @RequestParam String vehicleType, @RequestParam String color,
                       @RequestParam int seats, HttpSession session, Model model) {
        Long userId = (Long) session.getAttribute("userId");
        if (userId == null) return "redirect:/login";
        if (!"DRIVER".equals(session.getAttribute("userRole"))) return "redirect:/dashboard";
        try {
            vehicleService.addVehicle(userId, vehicleNumber, model_, vehicleType, color, seats);
        } catch (IllegalArgumentException | DataIntegrityViolationException ex) {
            model.addAttribute("error", ex instanceof DataIntegrityViolationException
                    ? "This vehicle number is already registered."
                    : ex.getMessage());
            model.addAttribute("vehicles", vehicleService.getVehiclesForUser(userId));
            return "vehicle";
        }
        return "redirect:/vehicle";
    }

    @PostMapping("/update")
    public String update(@RequestParam Long vehicleId, @RequestParam String vehicleNumber,
                          @RequestParam String model_, @RequestParam String vehicleType,
                          @RequestParam String color, @RequestParam int seats, HttpSession session, Model model) {
        Long userId = (Long) session.getAttribute("userId");
        if (userId == null) return "redirect:/login";
        if (!"DRIVER".equals(session.getAttribute("userRole"))) return "redirect:/dashboard";

        Vehicle vehicle = new Vehicle();
        vehicle.setId(vehicleId);
        vehicle.setUserId(userId);
        vehicle.setVehicleNumber(vehicleNumber);
        vehicle.setModel(model_);
        vehicle.setVehicleType(vehicleType);
        vehicle.setColor(color);
        vehicle.setSeats(seats);
        try {
            vehicleService.updateVehicle(vehicle);
        } catch (IllegalArgumentException | DataIntegrityViolationException ex) {
            model.addAttribute("error", ex instanceof DataIntegrityViolationException
                    ? "This vehicle number is already registered." : ex.getMessage());
            model.addAttribute("vehicles", vehicleService.getVehiclesForUser(userId));
            return "vehicle";
        }
        return "redirect:/vehicle";
    }

    @PostMapping("/delete")
    public String delete(@RequestParam Long vehicleId, HttpSession session) {
        Long userId = (Long) session.getAttribute("userId");
        if (userId == null) return "redirect:/login";
        if (!"DRIVER".equals(session.getAttribute("userRole"))) return "redirect:/dashboard";
        vehicleService.deleteVehicle(vehicleId, userId);
        return "redirect:/vehicle";
    }
}
