package com.carpooling.controller;

import com.carpooling.model.User;
import com.carpooling.service.BookingService;
import com.carpooling.service.NotificationService;
import com.carpooling.service.RatingService;
import com.carpooling.service.RideService;
import com.carpooling.service.UserService;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.Map;

@Controller
public class UserController {

    private final UserService userService;
    private final RideService rideService;
    private final RatingService ratingService;
    private final NotificationService notificationService;
    private final BookingService bookingService;

    public UserController(UserService userService, RideService rideService,
                           RatingService ratingService, NotificationService notificationService,
                           BookingService bookingService) {
        this.userService = userService;
        this.rideService = rideService;
        this.ratingService = ratingService;
        this.notificationService = notificationService;
        this.bookingService = bookingService;
    }

    /** Role-aware dashboard entry point (Section 14 / 15). */
    @GetMapping("/dashboard")
    public String dashboard(HttpSession session, Model model) {
        Long userId = (Long) session.getAttribute("userId");
        if (userId == null) return "redirect:/login";

        User user = userService.findById(userId).orElseThrow();
        model.addAttribute("user", user);

        if ("ADMIN".equals(user.getRole())) {
            return "redirect:/admin/dashboard";
        }

        if ("DRIVER".equals(user.getRole())) {
            model.addAttribute("rides", rideService.findByDriverId(userId));
            model.addAttribute("ratingSummary", ratingService.summaryForDriver(userId));
            return "dashboard-driver";
        } else {
            model.addAttribute("bookings", bookingService.findByPassengerId(userId));
            return "dashboard-passenger";
        }
    }

    @GetMapping("/profile")
    public String profile(HttpSession session, Model model) {
        Long userId = (Long) session.getAttribute("userId");
        if (userId == null) return "redirect:/login";
        User user = userService.findById(userId).orElseThrow();
        model.addAttribute("user", user);
        Object profileError = session.getAttribute("profileError");
        if (profileError != null) {
            model.addAttribute("error", profileError.toString());
            session.removeAttribute("profileError");
        }
        Object profileSuccess = session.getAttribute("profileSuccess");
        if (profileSuccess != null) {
            model.addAttribute("success", profileSuccess.toString());
            session.removeAttribute("profileSuccess");
        }
        if ("DRIVER".equals(user.getRole())) {
            Map<String, Object> summary = ratingService.summaryForDriver(userId);
            model.addAttribute("ratingSummary", summary);
        }
        return "profile";
    }

    @PostMapping("/profile/update")
    public String updateProfile(@RequestParam String name, @RequestParam String phone,
                                 @RequestParam String city, HttpSession session, Model model) {
        Long userId = (Long) session.getAttribute("userId");
        if (userId == null) return "redirect:/login";

        User user = new User();
        user.setId(userId);
        user.setName(name);
        user.setPhone(phone);
        user.setCity(city);
        try {
            userService.updateProfile(user);
            session.setAttribute("userName", name.trim());
            session.setAttribute("profileSuccess", "Profile updated successfully.");
        } catch (org.springframework.dao.DataIntegrityViolationException ex) {
            session.setAttribute("profileError", "That phone number is already linked to another account.");
        } catch (IllegalArgumentException ex) {
            session.setAttribute("profileError", ex.getMessage());
        }
        return "redirect:/profile";
    }

    @PostMapping("/profile/change-password")
    public String changePassword(@RequestParam String currentPassword, @RequestParam String newPassword,
                                  @RequestParam String confirmPassword, HttpSession session, Model model) {
        Long userId = (Long) session.getAttribute("userId");
        if (userId == null) return "redirect:/login";
        try {
            if (!newPassword.equals(confirmPassword)) throw new IllegalArgumentException("New passwords do not match.");
            userService.changePassword(userId, currentPassword, newPassword);
        } catch (IllegalArgumentException ex) {
            session.setAttribute("profileError", ex.getMessage());
        }
        return "redirect:/profile";
    }

    @GetMapping("/notifications")
    public String notifications(HttpSession session, Model model) {
        Long userId = (Long) session.getAttribute("userId");
        if (userId == null) return "redirect:/login";
        model.addAttribute("notifications", notificationService.getForUser(userId));
        notificationService.markAllRead(userId);
        return "notifications";
    }
}
