<%@ page contentType="text/html;charset=UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<%@ taglib prefix="fn" uri="jakarta.tags.functions" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Find a Ride - RideShare</title>
    <jsp:include page="includes/head.jsp"/>
</head>
<body>
<div class="bg-glow"></div>
<jsp:include page="includes/navbar.jsp"/>

<div class="container section" style="padding-top:32px;">
    <h2 class="reveal">Find your ride</h2>

    <form id="search-form" class="card" style="margin-bottom:28px;" action="${pageContext.request.contextPath}/search-rides/results" method="get">
        <div class="form-row" style="grid-template-columns:1fr 1fr 1fr 1fr auto;gap:12px;align-items:end;">
            <div class="form-group" style="margin-bottom:0;">
                <label>From</label>
                <input class="form-control" type="text" name="source" value="${source}" placeholder="Source city">
            </div>
            <div class="form-group" style="margin-bottom:0;">
                <label>To</label>
                <input class="form-control" type="text" name="destination" value="${destination}" placeholder="Destination city">
            </div>
            <div class="form-group" style="margin-bottom:0;">
                <label>Date</label>
                <input class="form-control" type="date" name="date" value="${date}">
            </div>
            <div class="form-group" style="margin-bottom:0;">
                <label>Seats</label>
                <input class="form-control" type="number" name="seats" value="${empty seats ? 1 : seats}" min="1" max="8">
            </div>
            <button type="submit" class="btn btn-primary">Search</button>
        </div>
    </form>

    <div class="search-layout">
        <aside class="filters-panel glass reveal">
            <h4>Refine Results</h4>
            <div class="filter-group">
                <label>Max cost per seat (&#8377;)</label>
                <input class="form-control" type="number" name="maxCost" form="search-form">
            </div>
            <div class="filter-group">
                <label>Minimum driver rating</label>
                <select class="form-control" name="minRating" form="search-form">
                    <option value="">Any</option>
                    <option value="3">3+ stars</option>
                    <option value="4">4+ stars</option>
                    <option value="4.5">4.5+ stars</option>
                </select>
            </div>
            <div class="filter-group">
                <label>Vehicle type</label>
                <select class="form-control" name="vehicleType" form="search-form">
                    <option value="">Any</option>
                    <option value="HATCHBACK">Hatchback</option>
                    <option value="SEDAN">Sedan</option>
                    <option value="SUV">SUV</option>
                    <option value="BIKE">Bike</option>
                </select>
            </div>
            <button type="submit" form="search-form" class="btn btn-secondary btn-block btn-sm">Apply Filters</button>
        </aside>

        <div class="ride-list">
            <c:choose>
                <c:when test="${empty rides}">
                    <div class="card empty-state reveal">
                        <div class="icon">🔍</div>
                        <h3>${not empty source || not empty destination ? 'No rides match your search' : 'Search for a ride'}</h3>
                        <p>Try a different route, date, or fewer filters.</p>
                    </div>
                </c:when>
                <c:otherwise>
                    <c:forEach var="r" items="${rides}">
                        <div class="card ride-card reveal">
                            <div class="ride-card-top">
                                <div class="driver-info">
                                    <div class="avatar">${fn:substring(r.driverName, 0, 1)}</div>
                                    <div>
                                        <div class="name">${r.driverName}</div>
                                        <div class="rating">★ ${r.driverRating != null ? r.driverRating : 'New'}</div>
                                    </div>
                                </div>
                                <span class="badge badge-neutral">${r.vehicleType} · ${r.vehicleModel}</span>
                            </div>

                            <div class="route-line">${r.source} <span class="dash"></span> ${r.destination}</div>

                            <div class="ride-meta">
                                <span>📅 ${r.departureDate}</span>
                                <span>🕐 ${r.departureTime}</span>
                                <span>💺 ${r.availableSeats} seat(s) left</span>
                            </div>

                            <c:if test="${not empty r.routeCompatibility}">
                                <div class="compat-bar-wrap">
                                    <span>Route match</span>
                                    <div class="compat-bar"><div class="compat-bar-fill" data-value="${r.routeCompatibility}"></div></div>
                                    <span>${r.routeCompatibility}%</span>
                                </div>
                            </c:if>

                            <div class="ride-card-footer">
                                <span class="ride-price">&#8377;<fmt:formatNumber value="${r.costPerPerson}" pattern="0.00"/> <small>/ seat</small></span>
                                <a href="${pageContext.request.contextPath}/ride/${r.id}" class="btn btn-primary btn-sm">View & Book</a>
                            </div>
                        </div>
                    </c:forEach>
                </c:otherwise>
            </c:choose>
        </div>
    </div>
</div>

<jsp:include page="includes/footer.jsp"/>
<jsp:include page="includes/scripts.jsp"/>
</body>
</html>
