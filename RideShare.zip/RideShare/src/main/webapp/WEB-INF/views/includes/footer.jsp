<footer class="section" style="padding-top:48px;padding-bottom:32px;border-top:1px solid var(--border);">
    <div class="container" style="display:flex;justify-content:space-between;flex-wrap:wrap;gap:24px;align-items:center;">
        <div>
            <div class="navbar-logo">RideShare<span class="dot">.</span></div>
            <p class="text-muted" style="margin-top:6px;">Share the journey. Not the cost.</p>
        </div>
        <div class="text-muted" style="font-size:13.5px;">
            &copy; 2026 RideShare. Built as a college project demo.
        </div>
    </div>
</footer>
