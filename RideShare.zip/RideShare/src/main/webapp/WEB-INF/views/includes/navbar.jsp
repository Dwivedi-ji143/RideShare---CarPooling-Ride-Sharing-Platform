<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fn" uri="jakarta.tags.functions" %>
<div id="scroll-progress"></div>
<nav class="navbar">
    <div class="navbar-inner">
        <a href="${pageContext.request.contextPath}/" class="navbar-logo">RideShare<span class="dot">.</span></a>

        <div class="navbar-links">
            <a href="${pageContext.request.contextPath}/search-rides">Find Ride</a>
            <c:choose>
                <c:when test="${sessionScope.userRole == 'DRIVER'}">
                    <a href="${pageContext.request.contextPath}/offer-ride">Offer Ride</a>
                </c:when>
            </c:choose>
            <a href="${pageContext.request.contextPath}/#how-it-works">How It Works</a>
            <a href="${pageContext.request.contextPath}/#about">About</a>
        </div>

        <div class="navbar-actions">
            <c:choose>
                <c:when test="${not empty sessionScope.userId}">
                    <a href="${pageContext.request.contextPath}/notifications" class="notif-bell">🔔</a>
                    <a href="${pageContext.request.contextPath}/dashboard" class="avatar">
                        ${fn:substring(sessionScope.userName, 0, 1)}
                    </a>
                    <a href="${pageContext.request.contextPath}/logout" class="btn btn-secondary btn-sm">Logout</a>
                </c:when>
                <c:otherwise>
                    <a href="${pageContext.request.contextPath}/login" class="btn btn-secondary btn-sm">Login</a>
                    <a href="${pageContext.request.contextPath}/register" class="btn btn-primary btn-sm">Get Started</a>
                </c:otherwise>
            </c:choose>
            <button class="navbar-toggle">&#9776;</button>
        </div>
    </div>
</nav>
