<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<aside class="sidebar">
    <div class="sidebar-logo">RideShare<span class="dot" style="color:var(--accent)">.</span></div>

    <a href="${pageContext.request.contextPath}/dashboard" class="sidebar-link ${activePage == 'dashboard' ? 'active' : ''}">🏠 Dashboard</a>
    <a href="${pageContext.request.contextPath}/search-rides" class="sidebar-link ${activePage == 'search' ? 'active' : ''}">🔍 Find Ride</a>

    <c:if test="${sessionScope.userRole == 'DRIVER'}">
        <a href="${pageContext.request.contextPath}/offer-ride" class="sidebar-link ${activePage == 'offer' ? 'active' : ''}">➕ Offer Ride</a>
        <a href="${pageContext.request.contextPath}/my-rides" class="sidebar-link ${activePage == 'myrides' ? 'active' : ''}">🚗 My Rides</a>
        <a href="${pageContext.request.contextPath}/vehicle" class="sidebar-link ${activePage == 'vehicle' ? 'active' : ''}">🔧 My Vehicles</a>
    </c:if>
    <c:if test="${sessionScope.userRole == 'PASSENGER'}">
        <a href="${pageContext.request.contextPath}/bookings" class="sidebar-link ${activePage == 'bookings' ? 'active' : ''}">🎟 My Bookings</a>
    </c:if>

    <a href="${pageContext.request.contextPath}/notifications" class="sidebar-link ${activePage == 'notifications' ? 'active' : ''}">🔔 Notifications</a>
    <a href="${pageContext.request.contextPath}/report" class="sidebar-link ${activePage == 'report' ? 'active' : ''}">⚠️ Report Issue</a>
    <a href="${pageContext.request.contextPath}/profile" class="sidebar-link ${activePage == 'profile' ? 'active' : ''}">👤 Profile</a>

    <div class="sidebar-footer">
        <a href="${pageContext.request.contextPath}/logout" class="sidebar-link">🚪 Logout</a>
    </div>
</aside>
