<%@ page contentType="text/html;charset=UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Create Account - RideShare</title>
    <jsp:include page="includes/head.jsp"/>
</head>
<body>
<div class="bg-glow"></div>
<div class="auth-split">
    <div class="auth-brand">
        <div class="brand-mark">RideShare<span style="color:var(--accent)">.</span></div>
        <h2>Share the journey. Not the cost.</h2>
        <p>Create an account to start offering rides as a driver or finding rides as a passenger.</p>
    </div>
    <div class="auth-form-panel">
        <div class="auth-form-card glass scale-in">
            <h2>Create account</h2>
            <p class="sub">Join RideShare in less than a minute.</p>

            <c:if test="${not empty error}">
                <div class="alert alert-error">${error}</div>
            </c:if>

            <form id="register-form" method="post" action="${pageContext.request.contextPath}/register">
                <div class="role-toggle">
                    <label class="role-option ${empty role || role == 'PASSENGER' ? 'active' : ''}">
                        <input type="radio" name="role" value="PASSENGER" ${empty role || role == 'PASSENGER' ? 'checked' : ''}>
                        🧑 I'm a Passenger
                    </label>
                    <label class="role-option ${role == 'DRIVER' ? 'active' : ''}">
                        <input type="radio" name="role" value="DRIVER" ${role == 'DRIVER' ? 'checked' : ''}>
                        🚗 I'm a Driver
                    </label>
                </div>

                <div class="form-group">
                    <label>Full Name</label>
                    <input class="form-control" type="text" name="name" value="${name}" required>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label>Email</label>
                        <input class="form-control" type="email" name="email" value="${email}" required>
                    </div>
                    <div class="form-group">
                        <label>Phone</label>
                        <input class="form-control" type="tel" name="phone" value="${phone}" placeholder="9876543210" required>
                    </div>
                </div>
                <div class="form-group">
                    <label>City</label>
                    <input class="form-control" type="text" name="city" value="${city}" placeholder="Greater Noida">
                </div>
                <div class="form-row">
                    <div class="form-group password-wrapper">
                        <label>Password</label>
                        <input class="form-control" type="password" name="password" required>
                        <button type="button" class="password-toggle">👁</button>
                    </div>
                    <div class="form-group password-wrapper">
                        <label>Confirm Password</label>
                        <input class="form-control" type="password" name="confirmPassword" required>
                        <button type="button" class="password-toggle">👁</button>
                    </div>
                </div>

                <button type="submit" class="btn btn-primary btn-block">Create Account</button>
            </form>

            <div class="form-footer">
                Already have an account? <a href="${pageContext.request.contextPath}/login">Sign in</a>
            </div>
        </div>
    </div>
</div>
<jsp:include page="includes/scripts.jsp"/>
</body>
</html>
