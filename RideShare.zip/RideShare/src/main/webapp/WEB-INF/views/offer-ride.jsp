<%@ page contentType="text/html;charset=UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Offer a Ride - RideShare</title>
    <jsp:include page="includes/head.jsp"/>
</head>
<body>
<div class="app-shell">
    <c:set var="activePage" value="offer" scope="request"/>
    <jsp:include page="includes/sidebar.jsp"/>

    <main class="main-content" style="max-width:640px;">
        <div class="dash-header reveal"><h2>Offer a Ride</h2></div>

        <c:if test="${not empty error}">
            <div class="alert alert-error">${error}</div>
        </c:if>

        <c:choose>
            <c:when test="${empty vehicles}">
                <div class="card empty-state reveal">
                    <div class="icon">🚗</div>
                    <h3>Add a vehicle first</h3>
                    <p>You need to register a vehicle before offering rides.</p>
                    <a href="${pageContext.request.contextPath}/vehicle" class="btn btn-primary">Add Vehicle</a>
                </div>
            </c:when>
            <c:otherwise>
                <form class="card reveal" method="post" action="${pageContext.request.contextPath}/offer-ride">
                    <div class="form-group">
                        <label>Vehicle</label>
                        <select class="form-control" name="vehicleId" required>
                            <c:forEach var="v" items="${vehicles}">
                                <option value="${v.id}">${v.model} - ${v.vehicleNumber} (${v.seats} seats)</option>
                            </c:forEach>
                        </select>
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label>From</label>
                            <input class="form-control" type="text" name="source" placeholder="Greater Noida" required>
                        </div>
                        <div class="form-group">
                            <label>To</label>
                            <input class="form-control" type="text" name="destination" placeholder="Delhi" required>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label>Departure Date</label>
                            <input class="form-control" type="date" name="date" required>
                        </div>
                        <div class="form-group">
                            <label>Departure Time</label>
                            <input class="form-control" type="time" name="time" required>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label>Available Seats</label>
                            <input class="form-control" type="number" name="seats" min="1" max="8" value="1" required>
                        </div>
                        <div class="form-group">
                            <label>Distance (km)</label>
                            <input class="form-control" type="number" step="0.1" name="distanceKm" placeholder="45.0">
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label>Fuel Cost (&#8377;)</label>
                            <input class="form-control" type="number" step="0.01" name="fuelCost" placeholder="500">
                        </div>
                        <div class="form-group">
                            <label>Toll Cost (&#8377;)</label>
                            <input class="form-control" type="number" step="0.01" name="tollCost" placeholder="200">
                        </div>
                    </div>
                    <div class="form-group">
                        <label>Notes (optional)</label>
                        <textarea class="form-control" name="notes" placeholder="AC car, non-smoking, music allowed..."></textarea>
                    </div>
                    <button type="submit" class="btn btn-primary btn-block">Publish Ride</button>
                </form>
            </c:otherwise>
        </c:choose>
    </main>
</div>
<jsp:include page="includes/scripts.jsp"/>
</body>
</html>
