<%@ page contentType="text/html;charset=UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>RideShare - Share the Journey, Not the Cost</title>
    <jsp:include page="includes/head.jsp"/>
</head>
<body>
<div class="bg-glow"></div>
<jsp:include page="includes/navbar.jsp"/>

<section class="hero">
    <div class="hero-blob one"></div>
    <div class="hero-blob two"></div>
    <div class="hero-content">
        <h1>SHARE THE JOURNEY.<span class="accent-line">NOT THE COST.</span></h1>
        <p class="hero-sub">Find people going your way. Split fuel and toll costs, travel smarter, and meet people along your route.</p>

        <form class="search-box glass" action="${pageContext.request.contextPath}/search-rides/results" method="get">
            <div class="search-field">
                <label>From</label>
                <input type="text" name="source" placeholder="Greater Noida" required>
            </div>
            <div class="search-field">
                <label>To</label>
                <input type="text" name="destination" placeholder="Delhi" required>
            </div>
            <div class="search-field">
                <label>Date</label>
                <input type="date" name="date">
            </div>
            <button type="submit" class="btn btn-primary">Search Rides</button>
        </form>

        <div class="scroll-indicator">
            <span>&#8595; Scroll to explore</span>
        </div>
    </div>
</section>

<section class="section" id="how-it-works">
    <div class="container text-center reveal">
        <span class="section-eyebrow">How It Works</span>
        <h2>Find your ride in 3 simple steps</h2>
    </div>
    <div class="container card-grid" style="margin-top:40px;">
        <div class="card reveal">
            <h3>01. Search</h3>
            <p>Enter your route and date to see matching rides offered by verified drivers.</p>
        </div>
        <div class="card reveal">
            <h3>02. Book</h3>
            <p>Reserve your seat instantly. Seats are held securely so there's never any overbooking.</p>
        </div>
        <div class="card reveal">
            <h3>03. Travel</h3>
            <p>Meet your driver, split the cost fairly, and rate your experience afterward.</p>
        </div>
    </div>
</section>

<section class="section" id="about" style="background:var(--bg-elevated);">
    <div class="container text-center reveal">
        <span class="section-eyebrow">Why RideShare</span>
        <h2>Travel smarter, together</h2>
    </div>
    <div class="container card-grid" style="margin-top:40px;">
        <div class="card reveal">
            <h3>💰 Lower Cost</h3>
            <p>Split fuel and toll costs automatically across every passenger on the ride.</p>
        </div>
        <div class="card reveal">
            <h3>🛡 Trusted Drivers</h3>
            <p>Every driver is rated and reviewed by real passengers after every completed ride.</p>
        </div>
        <div class="card reveal">
            <h3>🗺 Better Routes</h3>
            <p>Our route-matching shows you how compatible a ride is with your exact journey.</p>
        </div>
    </div>
</section>

<section class="section text-center reveal">
    <div class="container">
        <h2>Ready to share the journey?</h2>
        <p style="max-width:420px;margin:0 auto 28px;">Join thousands of commuters already saving money and meeting new people on their daily routes.</p>
        <a href="${pageContext.request.contextPath}/register" class="btn btn-primary">Get Started</a>
    </div>
</section>

<jsp:include page="includes/footer.jsp"/>
<jsp:include page="includes/scripts.jsp"/>
</body>
</html>
