<%@ page contentType="text/html;charset=UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Notifications - RideShare</title>
    <jsp:include page="includes/head.jsp"/>
</head>
<body>
<div class="app-shell">
    <c:set var="activePage" value="notifications" scope="request"/>
    <jsp:include page="includes/sidebar.jsp"/>

    <main class="main-content" style="max-width:640px;">
        <div class="dash-header reveal"><h2>Notifications</h2></div>

        <c:choose>
            <c:when test="${empty notifications}">
                <div class="card empty-state reveal">
                    <div class="icon">🔔</div>
                    <h3>No notifications yet</h3>
                </div>
            </c:when>
            <c:otherwise>
                <div class="ride-list">
                    <c:forEach var="n" items="${notifications}">
                        <div class="card notif-item reveal ${n.read ? '' : ''}" style="display:flex;justify-content:space-between;align-items:center;">
                            <div>
                                <p style="margin-bottom:4px;color:var(--text-primary);">${n.message}</p>
                                <span class="text-muted" style="font-size:12.5px;">${n.createdAt}</span>
                            </div>
                            <c:if test="${!n.read}"><span class="notif-dot" style="position:static;border:none;"></span></c:if>
                        </div>
                    </c:forEach>
                </div>
            </c:otherwise>
        </c:choose>
    </main>
</div>
<jsp:include page="includes/scripts.jsp"/>
</body>
</html>
