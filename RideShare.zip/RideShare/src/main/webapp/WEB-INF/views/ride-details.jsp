<%@ page contentType="text/html;charset=UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<%@ taglib prefix="fn" uri="jakarta.tags.functions" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Ride Details - RideShare</title>
    <jsp:include page="includes/head.jsp"/>
</head>
<body>
<div class="bg-glow"></div>
<jsp:include page="includes/navbar.jsp"/>

<div class="container section" style="padding-top:32px;max-width:820px;">
    <c:if test="${not empty error}">
        <div class="alert alert-error">${error}</div>
    </c:if>

    <div class="card reveal">
        <div class="ride-card-top">
            <div class="driver-info">
                <div class="avatar" style="width:52px;height:52px;font-size:18px;">${fn:substring(ride.driverName, 0, 1)}</div>
                <div>
                    <div class="name" style="font-size:17px;">${ride.driverName}</div>
                    <div class="rating">★ ${ride.driverRating != null ? ride.driverRating : 'New driver'}</div>
                </div>
            </div>
            <span class="badge ${ride.status == 'ACTIVE' ? 'badge-success' : 'badge-neutral'}">${ride.status}</span>
        </div>

        <div class="route-visual">
            <div class="stop"><div class="pin"></div>${ride.source}</div>
            <div class="connector"></div>
            <div class="stop"><div class="pin" style="background:var(--success);"></div>${ride.destination}</div>
        </div>

        <div class="ride-meta" style="margin-bottom:16px;">
            <span>📅 ${ride.departureDate}</span>
            <span>🕐 ${ride.departureTime}</span>
            <span>🚗 ${ride.vehicleModel} (${ride.vehicleType})</span>
            <span>💺 ${ride.availableSeats}/${ride.totalSeats} seats available</span>
        </div>

        <c:if test="${not empty ride.notes}">
            <p>"${ride.notes}"</p>
        </c:if>

        <div class="cost-breakdown">
            <div class="cost-item">
                <div class="amount">&#8377;<fmt:formatNumber value="${ride.totalCost}" pattern="0.00"/></div>
                <div class="label">Total trip cost (fuel + toll)</div>
            </div>
            <div class="cost-item">
                <div class="amount">&#8377;<fmt:formatNumber value="${ride.costPerPerson}" pattern="0.00"/></div>
                <div class="label">Cost per seat</div>
            </div>
        </div>

        <c:if test="${ride.status == 'ACTIVE' && ride.availableSeats > 0}">
            <form id="book-form" method="post" action="${pageContext.request.contextPath}/ride/${ride.id}/book" style="display:flex;gap:12px;align-items:end;">
                <div class="form-group" style="margin-bottom:0;flex:1;">
                    <label>Seats to book</label>
                    <input id="seats-input" class="form-control" type="number" name="seats" value="1" min="1" max="${ride.availableSeats}">
                </div>
                <button type="submit" class="btn btn-primary">Book Now</button>
            </form>
        </c:if>
        <c:if test="${ride.availableSeats == 0}">
            <div class="alert alert-error">This ride is fully booked.</div>
        </c:if>
    </div>
</div>

<jsp:include page="includes/footer.jsp"/>
<jsp:include page="includes/scripts.jsp"/>
</body>
</html>
