<%@ page contentType="text/html;charset=UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Report Issue - RideShare</title>
    <jsp:include page="includes/head.jsp"/>
</head>
<body>
<div class="app-shell">
    <c:set var="activePage" value="report" scope="request"/>
    <jsp:include page="includes/sidebar.jsp"/>

    <main class="main-content" style="max-width:720px;">
        <div class="dash-header reveal">
            <div>
                <h2>Report an Issue</h2>
                <p>Tell us what happened and our team will review it.</p>
            </div>
        </div>

        <c:if test="${not empty error}">
            <div class="alert alert-error">${error}</div>
        </c:if>
        <c:if test="${not empty success}">
            <div class="alert alert-success">${success}</div>
        </c:if>

        <form class="card reveal" method="post" action="${pageContext.request.contextPath}/report">
            <div class="form-group">
                <label for="reportedUser">Reported User ID (optional)</label>
                <input id="reportedUser" class="form-control" type="number" name="reportedUser" min="1" placeholder="e.g. 12">
                <div class="field-error">Leave blank if the issue is not about a specific user.</div>
            </div>

            <div class="form-group">
                <label for="rideId">Ride ID (optional)</label>
                <input id="rideId" class="form-control" type="number" name="rideId" min="1" placeholder="e.g. 25">
            </div>

            <div class="form-group">
                <label for="reason">Reason</label>
                <select id="reason" class="form-control" name="reason" required>
                    <option value="">Select a reason</option>
                    <option value="Unsafe driving">Unsafe driving</option>
                    <option value="Harassment or inappropriate behaviour">Harassment or inappropriate behaviour</option>
                    <option value="Fake or misleading ride">Fake or misleading ride</option>
                    <option value="Payment or fare issue">Payment or fare issue</option>
                    <option value="No-show">No-show</option>
                    <option value="Other">Other</option>
                </select>
            </div>

            <div class="form-group">
                <label for="description">Description</label>
                <textarea id="description" class="form-control" name="description" maxlength="1000"
                          placeholder="Describe the problem clearly (optional, but recommended)." rows="6"></textarea>
            </div>

            <button type="submit" class="btn btn-primary btn-block">Submit Report</button>
        </form>
    </main>
</div>
<jsp:include page="includes/scripts.jsp"/>
</body>
</html>
