<%@ page contentType="text/html;charset=UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fn" uri="jakarta.tags.functions" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>My Profile - RideShare</title>
    <jsp:include page="includes/head.jsp"/>
</head>
<body>
<div class="app-shell">
    <c:set var="activePage" value="profile" scope="request"/>
    <jsp:include page="includes/sidebar.jsp"/>

    <main class="main-content" style="max-width:600px;">
        <div class="dash-header reveal"><h2>My Profile</h2></div>

        <c:if test="${not empty error}"><div class="alert alert-error">${error}</div></c:if>
        <c:if test="${not empty success}"><div class="alert alert-success">${success}</div></c:if>

        <div class="card reveal" style="margin-bottom:24px;display:flex;align-items:center;gap:16px;">
            <div class="avatar" style="width:64px;height:64px;font-size:22px;">${fn:substring(user.name, 0, 1)}</div>
            <div>
                <h3 style="margin-bottom:2px;">${user.name}</h3>
                <p style="margin-bottom:4px;">${user.email}</p>
                <span class="badge badge-neutral">${user.role}</span>
                <c:if test="${user.role == 'DRIVER' && not empty ratingSummary.avg_rating}">
                    <span class="badge badge-success">★ ${ratingSummary.avg_rating} (${ratingSummary.review_count} reviews)</span>
                </c:if>
            </div>
        </div>

        <form class="card reveal" method="post" action="${pageContext.request.contextPath}/profile/update" style="margin-bottom:24px;">
            <h3 style="margin-bottom:16px;">Edit Details</h3>
            <div class="form-group">
                <label>Full Name</label>
                <input class="form-control" type="text" name="name" value="${user.name}" required>
            </div>
            <div class="form-group">
                <label>Phone</label>
                <input class="form-control" type="tel" name="phone" value="${user.phone}" required>
            </div>
            <div class="form-group">
                <label>City</label>
                <input class="form-control" type="text" name="city" value="${user.city}">
            </div>
            <button type="submit" class="btn btn-primary">Save Changes</button>
        </form>

        <form class="card reveal" method="post" action="${pageContext.request.contextPath}/profile/change-password">
            <h3 style="margin-bottom:16px;">Change Password</h3>
            <div class="form-group">
                <label>Current Password</label>
                <input class="form-control" type="password" name="currentPassword" required>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label>New Password</label>
                    <input class="form-control" type="password" name="newPassword" required>
                </div>
                <div class="form-group">
                    <label>Confirm New Password</label>
                    <input class="form-control" type="password" name="confirmPassword" required>
                </div>
            </div>
            <button type="submit" class="btn btn-secondary">Update Password</button>
        </form>
    </main>
</div>
<jsp:include page="includes/scripts.jsp"/>
</body>
</html>
