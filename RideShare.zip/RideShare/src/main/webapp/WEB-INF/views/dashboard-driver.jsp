<%@ page contentType="text/html;charset=UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Driver Dashboard - RideShare</title>
    <jsp:include page="includes/head.jsp"/>
</head>
<body>
<div class="app-shell">
    <c:set var="activePage" value="dashboard" scope="request"/>
    <jsp:include page="includes/sidebar.jsp"/>

    <main class="main-content">
        <div class="dash-header reveal">
            <div>
                <h2>Welcome back, ${user.name}</h2>
                <p>Manage your rides and track your earnings.</p>
            </div>
            <a href="${pageContext.request.contextPath}/offer-ride" class="btn btn-primary">➕ Offer a Ride</a>
        </div>

        <div class="stat-grid reveal">
            <div class="card stat-card">
                <div class="value">${rides.size()}</div>
                <div class="label">Rides Offered</div>
            </div>
            <div class="card stat-card">
                <c:set var="activeCount" value="0"/>
                <c:forEach var="r" items="${rides}">
                    <c:if test="${r.status == 'ACTIVE'}"><c:set var="activeCount" value="${activeCount + 1}"/></c:if>
                </c:forEach>
                <div class="value">${activeCount}</div>
                <div class="label">Active Rides</div>
            </div>
            <div class="card stat-card">
                <div class="value">${ratingSummary.avg_rating != null ? ratingSummary.avg_rating : '—'}</div>
                <div class="label">Average Rating</div>
            </div>
            <div class="card stat-card">
                <div class="value">${ratingSummary.review_count != null ? ratingSummary.review_count : 0}</div>
                <div class="label">Total Reviews</div>
            </div>
        </div>

        <div class="section-heading-row reveal">
            <h3>Your Rides</h3>
            <a href="${pageContext.request.contextPath}/my-rides" style="font-size:14px;color:var(--accent);font-weight:600;">View all &rarr;</a>
        </div>

        <c:choose>
            <c:when test="${empty rides}">
                <div class="card empty-state reveal">
                    <div class="icon">🚙</div>
                    <h3>No rides offered yet</h3>
                    <p>Offer your first ride to start finding passengers.</p>
                    <a href="${pageContext.request.contextPath}/offer-ride" class="btn btn-primary">Offer a Ride</a>
                </div>
            </c:when>
            <c:otherwise>
                <div class="ride-list">
                    <c:forEach var="r" items="${rides}" begin="0" end="2">
                        <div class="card ride-card reveal">
                            <div class="ride-card-top">
                                <div class="route-line">${r.source} <span class="dash"></span> ${r.destination}</div>
                                <span class="badge ${r.status == 'ACTIVE' ? 'badge-success' : r.status == 'CANCELLED' ? 'badge-error' : 'badge-neutral'}">${r.status}</span>
                            </div>
                            <div class="ride-meta">
                                <span>📅 ${r.departureDate}</span>
                                <span>🕐 ${r.departureTime}</span>
                                <span>💺 ${r.availableSeats}/${r.totalSeats} seats left</span>
                                <span>👥 ${r.passengerCount} booked</span>
                            </div>
                            <div class="ride-card-footer">
                                <a href="${pageContext.request.contextPath}/ride/${r.id}" class="btn btn-secondary btn-sm">View Details</a>
                            </div>
                        </div>
                    </c:forEach>
                </div>
            </c:otherwise>
        </c:choose>
    </main>
</div>
<jsp:include page="includes/scripts.jsp"/>
</body>
</html>
