<%@ page contentType="text/html;charset=UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Login - RideShare</title>
    <jsp:include page="includes/head.jsp"/>
</head>
<body>
<div class="bg-glow"></div>
<div class="auth-split">
    <div class="auth-brand">
        <div class="brand-mark">RideShare<span style="color:var(--accent)">.</span></div>
        <h2>Welcome back to your daily commute community.</h2>
        <p>Log in to find rides, manage bookings, and connect with drivers along your route.</p>
    </div>
    <div class="auth-form-panel">
        <div class="auth-form-card glass scale-in">
            <h2>Sign in</h2>
            <p class="sub">Enter your details to access your account.</p>

            <c:if test="${not empty error}">
                <div class="alert alert-error">${error}</div>
            </c:if>

            <form method="post" action="${pageContext.request.contextPath}/login">
                <div class="form-group">
                    <label>Email</label>
                    <input class="form-control" type="email" name="email" value="${email}" placeholder="you@example.com" required>
                </div>
                <div class="form-group password-wrapper">
                    <label>Password</label>
                    <input class="form-control" type="password" name="password" placeholder="••••••••" required>
                    <button type="button" class="password-toggle">👁</button>
                </div>
                <button type="submit" class="btn btn-primary btn-block">Sign In</button>
            </form>

            <div class="form-footer">
                Don't have an account? <a href="${pageContext.request.contextPath}/register">Create one</a>
            </div>
        </div>
    </div>
</div>
<jsp:include page="includes/scripts.jsp"/>
</body>
</html>
