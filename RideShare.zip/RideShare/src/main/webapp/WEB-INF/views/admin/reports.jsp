<%@ page contentType="text/html;charset=UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Reports - RideShare</title>
    <jsp:include page="../includes/head.jsp"/>
</head>
<body>
<div class="admin-shell">
    <aside class="admin-sidebar">
        <div class="sidebar-logo" style="margin-bottom:8px;">RideShare<span class="dot" style="color:var(--accent)">.</span></div>
        <span class="badge-admin">Administrator</span>
        <a class="sidebar-link" href="${pageContext.request.contextPath}/admin/dashboard">📊 Dashboard</a>
        <a class="sidebar-link" href="${pageContext.request.contextPath}/admin/users">👥 Users</a>
        <a class="sidebar-link active" href="${pageContext.request.contextPath}/admin/reports">⚠️ Reports</a>
        <div class="sidebar-footer"><a class="sidebar-link" href="${pageContext.request.contextPath}/logout">🚪 Logout</a></div>
    </aside>

    <main class="main-content">
        <div class="dash-header reveal">
            <div><h2>Reported Issues</h2><p>Review reports submitted by users.</p></div>
        </div>

        <div class="table-wrap card reveal" style="padding:0;overflow-x:auto;">
            <table class="data-table">
                <thead>
                <tr><th>ID</th><th>Reported By</th><th>Reported User</th><th>Ride</th><th>Reason</th><th>Description</th><th>Status</th><th>Action</th></tr>
                </thead>
                <tbody>
                <c:choose>
                    <c:when test="${empty reports}">
                        <tr><td colspan="8">No reports have been submitted.</td></tr>
                    </c:when>
                    <c:otherwise>
                        <c:forEach var="r" items="${reports}">
                            <tr>
                                <td>#${r.id}</td>
                                <td>${r.reporterName}</td>
                                <td>${not empty r.reportedUserName ? r.reportedUserName : '—'}</td>
                                <td>${not empty r.rideId ? r.rideId : '—'}</td>
                                <td>${r.reason}</td>
                                <td>${not empty r.description ? r.description : '—'}</td>
                                <td><span class="badge ${r.status == 'OPEN' ? 'badge-error' : r.status == 'RESOLVED' ? 'badge-success' : 'badge-neutral'}">${r.status}</span></td>
                                <td>
                                    <c:if test="${r.status != 'RESOLVED'}">
                                        <form method="post" action="${pageContext.request.contextPath}/admin/reports/${r.id}/resolve">
                                            <button type="submit" class="btn btn-primary btn-sm">Resolve</button>
                                        </form>
                                    </c:if>
                                </td>
                            </tr>
                        </c:forEach>
                    </c:otherwise>
                </c:choose>
                </tbody>
            </table>
        </div>
    </main>
</div>
<jsp:include page="../includes/scripts.jsp"/>
</body>
</html>
