<%@ page contentType="text/html;charset=UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Manage Users - RideShare</title>
    <jsp:include page="../includes/head.jsp"/>
</head>
<body>
<div class="admin-shell">
    <aside class="admin-sidebar">
        <div class="sidebar-logo" style="margin-bottom:8px;">RideShare<span class="dot" style="color:var(--accent)">.</span></div>
        <span class="badge-admin">Administrator</span>
        <a class="sidebar-link" href="${pageContext.request.contextPath}/admin/dashboard">📊 Dashboard</a>
        <a class="sidebar-link active" href="${pageContext.request.contextPath}/admin/users">👥 Users</a>
        <a class="sidebar-link" href="${pageContext.request.contextPath}/admin/reports">⚠️ Reports</a>
        <div class="sidebar-footer"><a class="sidebar-link" href="${pageContext.request.contextPath}/logout">🚪 Logout</a></div>
    </aside>

    <main class="main-content">
        <div class="dash-header reveal">
            <div><h2>Users</h2><p>Manage registered RideShare accounts.</p></div>
        </div>

        <div class="table-wrap card reveal" style="padding:0;overflow-x:auto;">
            <table class="data-table">
                <thead><tr><th>ID</th><th>Name</th><th>Email</th><th>Phone</th><th>Role</th><th>Status</th><th>Action</th></tr></thead>
                <tbody>
                <c:forEach var="u" items="${users}">
                    <tr>
                        <td>#${u.id}</td>
                        <td>${u.name}</td>
                        <td>${u.email}</td>
                        <td>${u.phone}</td>
                        <td>${u.role}</td>
                        <td><span class="badge ${u.status == 'ACTIVE' ? 'badge-success' : 'badge-error'}">${u.status}</span></td>
                        <td>
                            <c:choose>
                                <c:when test="${u.status == 'ACTIVE'}">
                                    <form method="post" action="${pageContext.request.contextPath}/admin/users/${u.id}/suspend">
                                        <button type="submit" class="btn btn-danger btn-sm" data-confirm="Suspend this user?">Suspend</button>
                                    </form>
                                </c:when>
                                <c:otherwise>
                                    <form method="post" action="${pageContext.request.contextPath}/admin/users/${u.id}/reactivate">
                                        <button type="submit" class="btn btn-primary btn-sm">Reactivate</button>
                                    </form>
                                </c:otherwise>
                            </c:choose>
                        </td>
                    </tr>
                </c:forEach>
                </tbody>
            </table>
        </div>
    </main>
</div>
<jsp:include page="../includes/scripts.jsp"/>
</body>
</html>
