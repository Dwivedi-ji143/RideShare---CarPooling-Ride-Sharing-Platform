<%@ page contentType="text/html;charset=UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Admin Dashboard - RideShare</title>
    <jsp:include page="../includes/head.jsp"/>
</head>
<body>
<div class="admin-shell">
    <aside class="admin-sidebar">
        <div class="sidebar-logo" style="margin-bottom:8px;">RideShare<span class="dot" style="color:var(--accent)">.</span></div>
        <span class="badge-admin">Administrator</span>
        <a class="sidebar-link active" href="${pageContext.request.contextPath}/admin/dashboard">📊 Dashboard</a>
        <a class="sidebar-link" href="${pageContext.request.contextPath}/admin/users">👥 Users</a>
        <a class="sidebar-link" href="${pageContext.request.contextPath}/admin/reports">⚠️ Reports</a>
        <a class="sidebar-link" href="${pageContext.request.contextPath}/dashboard">🏠 User Dashboard</a>
        <div class="sidebar-footer">
            <a class="sidebar-link" href="${pageContext.request.contextPath}/logout">🚪 Logout</a>
        </div>
    </aside>

    <main class="main-content">
        <div class="dash-header reveal">
            <div>
                <h2>Admin Dashboard</h2>
                <p>Monitor users, rides, bookings and reported issues.</p>
            </div>
        </div>

        <div class="stat-grid reveal">
            <div class="card stat-card"><div class="value">${stats.totalPassengers}</div><div class="label">Passengers</div></div>
            <div class="card stat-card"><div class="value">${stats.totalDrivers}</div><div class="label">Drivers</div></div>
            <div class="card stat-card"><div class="value">${stats.totalVehicles}</div><div class="label">Vehicles</div></div>
            <div class="card stat-card"><div class="value">${stats.totalRides}</div><div class="label">Total Rides</div></div>
            <div class="card stat-card"><div class="value">${stats.activeRides}</div><div class="label">Active Rides</div></div>
            <div class="card stat-card"><div class="value">${stats.totalBookings}</div><div class="label">Bookings</div></div>
            <div class="card stat-card"><div class="value">${stats.openReports}</div><div class="label">Open Reports</div></div>
        </div>

        <div class="section-heading-row reveal">
            <h3>Popular Routes</h3>
            <a href="${pageContext.request.contextPath}/admin/reports" style="font-size:14px;color:var(--accent);font-weight:600;">Review reports →</a>
        </div>

        <div class="table-wrap card reveal" style="padding:0;">
            <table class="data-table">
                <thead><tr><th>Source</th><th>Destination</th><th>Rides</th></tr></thead>
                <tbody>
                <c:choose>
                    <c:when test="${empty popularRoutes}">
                        <tr><td colspan="3">No route data available.</td></tr>
                    </c:when>
                    <c:otherwise>
                        <c:forEach var="route" items="${popularRoutes}">
                            <tr>
                                <td>${route.source}</td>
                                <td>${route.destination}</td>
                                <td>${route.ride_count}</td>
                            </tr>
                        </c:forEach>
                    </c:otherwise>
                </c:choose>
                </tbody>
            </table>
        </div>
    </main>
</div>
<jsp:include page="../includes/scripts.jsp"/>
</body>
</html>
