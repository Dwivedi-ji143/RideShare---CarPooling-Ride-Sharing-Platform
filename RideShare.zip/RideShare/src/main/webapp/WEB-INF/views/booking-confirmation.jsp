<%@ page contentType="text/html;charset=UTF-8" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Booking Confirmed - RideShare</title>
    <jsp:include page="includes/head.jsp"/>
</head>
<body>
<div class="bg-glow"></div>
<jsp:include page="includes/navbar.jsp"/>

<div class="container section" style="padding-top:48px;max-width:720px;">
    <div class="card reveal" style="text-align:center;padding:48px 32px;">
        <div style="font-size:56px;margin-bottom:16px;">✓</div>
        <h2>Booking Confirmed</h2>
        <p style="margin:8px 0 28px;color:var(--text-secondary);">Your ride has been booked successfully.</p>

        <div class="card" style="text-align:left;margin-bottom:24px;background:var(--surface);">
            <div class="ride-meta" style="display:grid;gap:12px;">
                <span><strong>Booking ID:</strong> #${booking.id}</span>
                <span><strong>Route:</strong> ${booking.source} → ${booking.destination}</span>
                <span><strong>Date:</strong> ${booking.departureDate}</span>
                <span><strong>Time:</strong> ${booking.departureTime}</span>
                <span><strong>Driver:</strong> ${booking.driverName}</span>
                <span><strong>Seats:</strong> ${booking.seatsBooked}</span>
                <span><strong>Total:</strong> &#8377;<fmt:formatNumber value="${booking.amount}" pattern="0.00"/></span>
                <span><strong>Status:</strong> ${booking.status}</span>
            </div>
        </div>

        <div style="display:flex;gap:12px;justify-content:center;flex-wrap:wrap;">
            <a href="${pageContext.request.contextPath}/bookings" class="btn btn-primary">View My Bookings</a>
            <a href="${pageContext.request.contextPath}/search-rides" class="btn btn-secondary">Find Another Ride</a>
        </div>
    </div>
</div>

<jsp:include page="includes/footer.jsp"/>
<jsp:include page="includes/scripts.jsp"/>
</body>
</html>
