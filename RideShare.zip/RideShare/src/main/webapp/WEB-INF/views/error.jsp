<%@ page contentType="text/html;charset=UTF-8" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Something went wrong - RideShare</title>
    <jsp:include page="includes/head.jsp"/>
</head>
<body>
<div class="bg-glow"></div>
<div style="min-height:100vh;display:grid;place-items:center;padding:24px;">
    <div class="glass card" style="max-width:620px;width:100%;text-align:center;padding:52px 36px;">
        <div style="font-size:56px;margin-bottom:16px;">⚠️</div>
        <span class="section-eyebrow">RideShare</span>
        <h1 style="font-size:42px;">Something went wrong</h1>
        <p>${errorMessage}</p>
        <div style="display:flex;gap:12px;justify-content:center;flex-wrap:wrap;margin-top:28px;">
            <a class="btn btn-primary" href="${pageContext.request.contextPath}/">Back to Home</a>
            <a class="btn btn-secondary" href="${pageContext.request.contextPath}/login">Sign In</a>
        </div>
    </div>
</div>
</body>
</html>
