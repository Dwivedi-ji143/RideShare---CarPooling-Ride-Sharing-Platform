<%@ page contentType="text/html;charset=UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>My Vehicles - RideShare</title>
    <jsp:include page="includes/head.jsp"/>
</head>
<body>
<div class="app-shell">
    <c:set var="activePage" value="vehicle" scope="request"/>
    <jsp:include page="includes/sidebar.jsp"/>

    <main class="main-content" style="max-width:720px;">
        <div class="dash-header reveal"><h2>My Vehicles</h2></div>

        <c:if test="${not empty error}">
            <div class="alert alert-error">${error}</div>
        </c:if>

        <form class="card reveal" method="post" action="${pageContext.request.contextPath}/vehicle/add" style="margin-bottom:28px;">
            <h3 style="margin-bottom:16px;">Add a Vehicle</h3>
            <div class="form-row">
                <div class="form-group">
                    <label>Vehicle Number</label>
                    <input class="form-control" type="text" name="vehicleNumber" placeholder="UP16 XX 1234" required>
                </div>
                <div class="form-group">
                    <label>Model</label>
                    <input class="form-control" type="text" name="model_" placeholder="Hyundai Creta" required>
                </div>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label>Type</label>
                    <select class="form-control" name="vehicleType">
                        <option value="HATCHBACK">Hatchback</option>
                        <option value="SEDAN" selected>Sedan</option>
                        <option value="SUV">SUV</option>
                        <option value="BIKE">Bike</option>
                        <option value="OTHER">Other</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>Color</label>
                    <input class="form-control" type="text" name="color" placeholder="White">
                </div>
            </div>
            <div class="form-group">
                <label>Total Seats</label>
                <input class="form-control" type="number" name="seats" min="1" max="8" value="4" required>
            </div>
            <button type="submit" class="btn btn-primary btn-block">Add Vehicle</button>
        </form>

        <h3 class="reveal" style="margin-bottom:16px;">Your Vehicles</h3>
        <c:choose>
            <c:when test="${empty vehicles}">
                <div class="card empty-state reveal">
                    <div class="icon">🔧</div>
                    <h3>No vehicles added yet</h3>
                </div>
            </c:when>
            <c:otherwise>
                <div class="card-grid">
                    <c:forEach var="v" items="${vehicles}">
                        <div class="card reveal">
                            <h3>${v.model}</h3>
                            <p>${v.vehicleNumber} · ${v.color}</p>
                            <div class="ride-meta" style="margin-bottom:16px;">
                                <span class="badge badge-neutral">${v.vehicleType}</span>
                                <span>💺 ${v.seats} seats</span>
                            </div>
                            <form method="post" action="${pageContext.request.contextPath}/vehicle/delete" data-confirm="Remove this vehicle?">
                                <input type="hidden" name="vehicleId" value="${v.id}">
                                <button type="submit" class="btn btn-danger btn-sm btn-block">Remove</button>
                            </form>
                        </div>
                    </c:forEach>
                </div>
            </c:otherwise>
        </c:choose>
    </main>
</div>
<jsp:include page="includes/scripts.jsp"/>
</body>
</html>
