<%@ page contentType="text/html;charset=UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>My Rides - RideShare</title>
    <jsp:include page="includes/head.jsp"/>
</head>
<body>
<div class="app-shell">
    <c:set var="activePage" value="myrides" scope="request"/>
    <jsp:include page="includes/sidebar.jsp"/>

    <main class="main-content">
        <div class="dash-header reveal">
            <h2>My Rides</h2>
            <a href="${pageContext.request.contextPath}/offer-ride" class="btn btn-primary">➕ Offer a Ride</a>
        </div>

        <c:choose>
            <c:when test="${empty rides}">
                <div class="card empty-state reveal">
                    <div class="icon">🚙</div>
                    <h3>No rides offered yet</h3>
                    <a href="${pageContext.request.contextPath}/offer-ride" class="btn btn-primary">Offer a Ride</a>
                </div>
            </c:when>
            <c:otherwise>
                <div class="ride-list">
                    <c:forEach var="r" items="${rides}">
                        <div class="card ride-card reveal">
                            <div class="ride-card-top">
                                <div class="route-line">${r.source} <span class="dash"></span> ${r.destination}</div>
                                <span class="badge ${r.status == 'ACTIVE' ? 'badge-success' : r.status == 'CANCELLED' ? 'badge-error' : 'badge-neutral'}">${r.status}</span>
                            </div>
                            <div class="ride-meta">
                                <span>📅 ${r.departureDate}</span>
                                <span>🕐 ${r.departureTime}</span>
                                <span>💺 ${r.availableSeats}/${r.totalSeats} seats left</span>
                                <span>👥 ${r.passengerCount} passenger(s) booked</span>
                            </div>
                            <div class="ride-card-footer">
                                <a href="${pageContext.request.contextPath}/ride/${r.id}" class="btn btn-secondary btn-sm">View Details</a>
                                <c:if test="${r.status == 'ACTIVE'}">
                                    <div style="display:flex;gap:10px;">
                                        <form method="post" action="${pageContext.request.contextPath}/ride/${r.id}/complete">
                                            <button type="submit" class="btn btn-secondary btn-sm">Mark Completed</button>
                                        </form>
                                        <form method="post" action="${pageContext.request.contextPath}/ride/${r.id}/cancel" data-confirm="Cancel this ride? All passengers will be notified.">
                                            <button type="submit" class="btn btn-danger btn-sm">Cancel</button>
                                        </form>
                                    </div>
                                </c:if>
                            </div>
                        </div>
                    </c:forEach>
                </div>
            </c:otherwise>
        </c:choose>
    </main>
</div>
<jsp:include page="includes/scripts.jsp"/>
</body>
</html>
