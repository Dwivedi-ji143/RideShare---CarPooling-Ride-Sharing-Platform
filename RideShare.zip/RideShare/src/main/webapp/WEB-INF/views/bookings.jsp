<%@ page contentType="text/html;charset=UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>My Bookings - RideShare</title>
    <jsp:include page="includes/head.jsp"/>
</head>
<body>
<div class="app-shell">
    <c:set var="activePage" value="bookings" scope="request"/>
    <jsp:include page="includes/sidebar.jsp"/>

    <main class="main-content">
        <div class="dash-header reveal"><h2>My Bookings</h2></div>

        <c:if test="${not empty error}">
            <div class="alert alert-error">${error}</div>
        </c:if>

        <c:choose>
            <c:when test="${empty bookings}">
                <div class="card empty-state reveal">
                    <div class="icon">🎟</div>
                    <h3>No bookings yet</h3>
                    <a href="${pageContext.request.contextPath}/search-rides" class="btn btn-primary">Find a Ride</a>
                </div>
            </c:when>
            <c:otherwise>
                <div class="ride-list">
                    <c:forEach var="b" items="${bookings}">
                        <div class="card ride-card reveal">
                            <div class="ride-card-top">
                                <div class="route-line">${b.source} <span class="dash"></span> ${b.destination}</div>
                                <span class="badge ${b.status == 'CONFIRMED' ? 'badge-success' : b.status == 'CANCELLED' ? 'badge-error' : 'badge-neutral'}">${b.status}</span>
                            </div>
                            <div class="ride-meta">
                                <span>📅 ${b.departureDate}</span>
                                <span>🕐 ${b.departureTime}</span>
                                <span>💺 ${b.seatsBooked} seat(s)</span>
                                <span>👤 Driver: ${b.driverName}</span>
                            </div>
                            <div class="ride-card-footer">
                                <span class="ride-price">&#8377;<fmt:formatNumber value="${b.amount}" pattern="0.00"/></span>
                                <c:if test="${b.status == 'CONFIRMED'}">
                                    <form method="post" action="${pageContext.request.contextPath}/booking/${b.id}/cancel" data-confirm="Cancel this booking?">
                                        <button type="submit" class="btn btn-danger btn-sm">Cancel Booking</button>
                                    </form>
                                </c:if>
                            </div>
                        </div>
                    </c:forEach>
                </div>
            </c:otherwise>
        </c:choose>
    </main>
</div>
<jsp:include page="includes/scripts.jsp"/>
</body>
</html>
