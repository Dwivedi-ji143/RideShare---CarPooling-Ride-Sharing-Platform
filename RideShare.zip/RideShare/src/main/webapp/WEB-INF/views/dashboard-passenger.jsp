<%@ page contentType="text/html;charset=UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Dashboard - RideShare</title>
    <jsp:include page="includes/head.jsp"/>
</head>
<body>
<div class="app-shell">
    <c:set var="activePage" value="dashboard" scope="request"/>
    <jsp:include page="includes/sidebar.jsp"/>

    <main class="main-content">
        <div class="dash-header reveal">
            <div>
                <h2>Welcome back, ${user.name}</h2>
                <p>Here's what's happening with your rides.</p>
            </div>
            <a href="${pageContext.request.contextPath}/search-rides" class="btn btn-primary">🔍 Find a Ride</a>
        </div>

        <div class="stat-grid reveal">
            <div class="card stat-card">
                <div class="value">${bookings.size()}</div>
                <div class="label">Total Bookings</div>
            </div>
            <div class="card stat-card">
                <c:set var="confirmedCount" value="0"/>
                <c:forEach var="b" items="${bookings}">
                    <c:if test="${b.status == 'CONFIRMED'}"><c:set var="confirmedCount" value="${confirmedCount + 1}"/></c:if>
                </c:forEach>
                <div class="value">${confirmedCount}</div>
                <div class="label">Upcoming Rides</div>
            </div>
        </div>

        <div class="section-heading-row reveal">
            <h3>Recent Bookings</h3>
            <a href="${pageContext.request.contextPath}/bookings" style="font-size:14px;color:var(--accent);font-weight:600;">View all &rarr;</a>
        </div>

        <c:choose>
            <c:when test="${empty bookings}">
                <div class="card empty-state reveal">
                    <div class="icon">🚗</div>
                    <h3>No bookings yet</h3>
                    <p>Search for a ride to get started.</p>
                    <a href="${pageContext.request.contextPath}/search-rides" class="btn btn-primary">Find a Ride</a>
                </div>
            </c:when>
            <c:otherwise>
                <div class="ride-list">
                    <c:forEach var="b" items="${bookings}" varStatus="status" begin="0" end="2">
                        <div class="card ride-card reveal">
                            <div class="route-line">
                                ${b.source} <span class="dash"></span> ${b.destination}
                            </div>
                            <div class="ride-meta">
                                <span>📅 ${b.departureDate}</span>
                                <span>🕐 ${b.departureTime}</span>
                                <span>💺 ${b.seatsBooked} seat(s)</span>
                                <span>👤 ${b.driverName}</span>
                            </div>
                            <div class="ride-card-footer">
                                <span class="badge ${b.status == 'CONFIRMED' ? 'badge-success' : b.status == 'CANCELLED' ? 'badge-error' : 'badge-neutral'}">${b.status}</span>
                                <span class="ride-price">&#8377;<fmt:formatNumber value="${b.amount}" pattern="0.00"/></span>
                            </div>
                        </div>
                    </c:forEach>
                </div>
            </c:otherwise>
        </c:choose>
    </main>
</div>
<jsp:include page="includes/scripts.jsp"/>
</body>
</html>
