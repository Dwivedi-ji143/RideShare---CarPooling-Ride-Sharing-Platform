document.addEventListener('DOMContentLoaded', () => {
    document.querySelectorAll('.notif-item').forEach(item => {
        item.addEventListener('click', () => {
            item.classList.add('read');
        });
    });
});
