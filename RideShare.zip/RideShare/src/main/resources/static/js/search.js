document.addEventListener('DOMContentLoaded', () => {
    // Animate compatibility bars from 0 to their data-value on load.
    document.querySelectorAll('.compat-bar-fill').forEach(fill => {
        const target = fill.getAttribute('data-value') || '0';
        requestAnimationFrame(() => {
            fill.style.width = target + '%';
        });
    });

    const searchForm = document.getElementById('search-form');
    if (searchForm) {
        searchForm.addEventListener('submit', () => {
            const btn = searchForm.querySelector('button[type="submit"]');
            if (btn) {
                btn.disabled = true;
                btn.innerHTML = '<span class="spinner"></span> Searching...';
            }
        });
    }
});
