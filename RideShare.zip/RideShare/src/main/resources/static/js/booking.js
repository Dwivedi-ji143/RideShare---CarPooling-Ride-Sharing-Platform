document.addEventListener('DOMContentLoaded', () => {
    const bookForm = document.getElementById('book-form');
    if (bookForm) {
        bookForm.addEventListener('submit', () => {
            const btn = bookForm.querySelector('button[type="submit"]');
            if (btn) {
                btn.disabled = true;
                btn.innerHTML = '<span class="spinner"></span> Confirming...';
            }
        });
    }

    // Clamp seat selector to available seats client-side (server still enforces the real limit).
    const seatsInput = document.getElementById('seats-input');
    if (seatsInput) {
        const max = parseInt(seatsInput.getAttribute('max') || '1', 10);
        seatsInput.addEventListener('change', () => {
            let val = parseInt(seatsInput.value, 10) || 1;
            if (val < 1) val = 1;
            if (val > max) val = max;
            seatsInput.value = val;
        });
    }
});
