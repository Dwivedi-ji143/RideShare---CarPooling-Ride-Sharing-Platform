// Lightweight client-side validation. Server-side validation in UserService/RideService
// remains the source of truth; this just gives immediate feedback.

document.addEventListener('DOMContentLoaded', () => {
    initPasswordToggle();
    initRegisterValidation();
    initRoleToggle();
});

function initPasswordToggle() {
    document.querySelectorAll('.password-toggle').forEach(btn => {
        btn.addEventListener('click', () => {
            const input = btn.closest('.password-wrapper').querySelector('input');
            const isPassword = input.type === 'password';
            input.type = isPassword ? 'text' : 'password';
            btn.textContent = isPassword ? '🙈' : '👁';
        });
    });
}

function initRoleToggle() {
    document.querySelectorAll('.role-option').forEach(label => {
        const input = label.querySelector('input');
        if (!input) return;
        input.addEventListener('change', () => {
            document.querySelectorAll('.role-option').forEach(l => l.classList.remove('active'));
            if (input.checked) label.classList.add('active');
        });
    });
}

function initRegisterValidation() {
    const form = document.getElementById('register-form');
    if (!form) return;

    form.addEventListener('submit', (e) => {
        const password = form.querySelector('[name="password"]');
        const confirm = form.querySelector('[name="confirmPassword"]');
        const email = form.querySelector('[name="email"]');
        const phone = form.querySelector('[name="phone"]');

        let error = null;
        if (password && password.value.length < 8) {
            error = 'Password must be at least 8 characters.';
        } else if (confirm && password.value !== confirm.value) {
            error = 'Passwords do not match.';
        } else if (email && !/^[\w.+-]+@[\w-]+\.[a-zA-Z]{2,}$/.test(email.value)) {
            error = 'Enter a valid email address.';
        } else if (phone && !/^[6-9]\d{9}$/.test(phone.value)) {
            error = 'Enter a valid 10-digit phone number.';
        }

        if (error) {
            e.preventDefault();
            showInlineError(form, error);
        }
    });
}

function showInlineError(form, message) {
    let box = form.querySelector('.js-inline-error');
    if (!box) {
        box = document.createElement('div');
        box.className = 'alert alert-error js-inline-error';
        form.prepend(box);
    }
    box.textContent = message;
}
