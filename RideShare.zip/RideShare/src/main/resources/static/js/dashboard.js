// Intentionally minimal: dashboard cards already get hover elevation from .card:hover in CSS.
// This file is reserved for future dashboard-only interactivity (e.g. live stat refresh).

document.addEventListener('DOMContentLoaded', () => {
    document.querySelectorAll('[data-confirm]').forEach(el => {
        el.addEventListener('submit', (e) => {
            const msg = el.getAttribute('data-confirm');
            if (!confirm(msg)) e.preventDefault();
        });
    });
});
