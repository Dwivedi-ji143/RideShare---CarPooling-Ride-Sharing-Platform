@echo off
setlocal
cd /d "%~dp0"
echo ===============================================
echo RideShare - Demo Database Setup
echo ===============================================
echo WARNING: This will DELETE and recreate carpooling_db.
echo.
where mysql >nul 2>nul
if errorlevel 1 (
  echo ERROR: mysql command was not found.
  echo Add MySQL 8.0 bin folder to PATH, or run database/reset-demo.sql in MySQL Workbench.
  pause
  exit /b 1
)
echo Enter your MySQL root password when prompted.
mysql -u root -p < database\reset-demo.sql
if errorlevel 1 (
  echo.
  echo Database setup failed. Check MySQL service and root password.
  pause
  exit /b 1
)
echo.
echo Database setup completed successfully.
pause
