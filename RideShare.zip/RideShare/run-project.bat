@echo off
setlocal
cd /d "%~dp0"
echo ===============================================
echo RideShare - Car Pooling and Ride Sharing Platform
echo ===============================================
echo.
where java >nul 2>nul
if errorlevel 1 (
  echo ERROR: Java is not installed or not in PATH.
  echo Install JDK 21 and configure JAVA_HOME/PATH.
  pause
  exit /b 1
)
java -version
echo.
where mvn >nul 2>nul
if errorlevel 1 (
  echo Maven command not found. Open this folder in Eclipse as an Existing Maven Project
  echo and run CarPoolingApplication.java.
  pause
  exit /b 1
)
echo Starting RideShare on http://localhost:8080 ...
echo.
mvn spring-boot:run
